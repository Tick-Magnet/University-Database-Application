/*
-- Query: SELECT * FROM university_data.enrolled
-- Date: 2021-11-15 10:25
*/
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (100001,'CS 101',80,100,90);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (100001,'CS 102',80,82,81);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (100001,'CS 151',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (100001,'CS 430',80,100,90);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (100001,'MATH 250',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (121212,'PS 101',100,100,100);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (121212,'PS 150',100,100,100);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (659832,'CS 101',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (659832,'CS 102',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (659832,'CS 103',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (659832,'CS 150',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (659832,'CS 151',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (885613,'CS 101',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (885613,'CS 102',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (885613,'CS 103',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (885613,'CS 150',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (885613,'MATH 150',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (912912,'CS 101',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (912912,'CS 102',NULL,NULL,NULL);
INSERT INTO `` (`sid`,`cid`,`exam1`,`exam2`,`final`) VALUES (912912,'CS 103',NULL,NULL,NULL);
