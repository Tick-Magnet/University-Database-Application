/*
-- Query: SELECT * FROM university_data.department
-- Date: 2021-11-15 10:24
*/
INSERT INTO `` (`did`,`dname`) VALUES (0,'University Faculty');
INSERT INTO `` (`did`,`dname`) VALUES (1,'Accounting');
INSERT INTO `` (`did`,`dname`) VALUES (2,'Architecture');
INSERT INTO `` (`did`,`dname`) VALUES (3,'Art');
INSERT INTO `` (`did`,`dname`) VALUES (4,'Biology');
INSERT INTO `` (`did`,`dname`) VALUES (5,'Chemistry');
INSERT INTO `` (`did`,`dname`) VALUES (6,'Classics');
INSERT INTO `` (`did`,`dname`) VALUES (7,'Computer Science ');
INSERT INTO `` (`did`,`dname`) VALUES (8,'Economics');
INSERT INTO `` (`did`,`dname`) VALUES (9,'English');
INSERT INTO `` (`did`,`dname`) VALUES (10,'Finance');
INSERT INTO `` (`did`,`dname`) VALUES (11,'French');
INSERT INTO `` (`did`,`dname`) VALUES (12,'German');
INSERT INTO `` (`did`,`dname`) VALUES (13,'Health');
INSERT INTO `` (`did`,`dname`) VALUES (14,'History');
INSERT INTO `` (`did`,`dname`) VALUES (15,'Management');
INSERT INTO `` (`did`,`dname`) VALUES (16,'Marketing');
INSERT INTO `` (`did`,`dname`) VALUES (17,'Mathematics');
INSERT INTO `` (`did`,`dname`) VALUES (18,'Medicine');
INSERT INTO `` (`did`,`dname`) VALUES (19,'Music');
INSERT INTO `` (`did`,`dname`) VALUES (20,'Philosophy');
INSERT INTO `` (`did`,`dname`) VALUES (21,'Physics');
INSERT INTO `` (`did`,`dname`) VALUES (22,'Psychology');
INSERT INTO `` (`did`,`dname`) VALUES (23,'Religion');
INSERT INTO `` (`did`,`dname`) VALUES (24,'Sociology');
INSERT INTO `` (`did`,`dname`) VALUES (25,'Statistics');
INSERT INTO `` (`did`,`dname`) VALUES (26,'Basket Weaving');
INSERT INTO `` (`did`,`dname`) VALUES (27,'Political Science');
INSERT INTO `` (`did`,`dname`) VALUES (28,'Underwater Basket Weaving');
