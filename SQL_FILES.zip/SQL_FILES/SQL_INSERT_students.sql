/*
-- Query: SELECT * FROM university_data.students
-- Date: 2021-11-15 10:26
*/
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (100001,'Jacob_Bowers','Computer_Science','Junior',20);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (121212,'Otto_von_Bismark','Geopolitics','Senior',83);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (131589,'Diane_Colby','English','Senior',21);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (215487,'Weldon_Quinten','Business','Junior',20);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (366666,'Jannah Lylah','Mathematics','Sophmore',20);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (455648,'Perlie_Dunstan','History','Freshman',19);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (659832,'Mervyn_Maci','Computer_Science','Masters',25);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (781245,'John_Locke','English','Sophmore',22);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (789845,'Diane_Franklyn','Mathematics','Freshman',19);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (847354,'Zandra_Colby','English','Masters',22);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (854854,'Franzika_Von_Karma','Law','PHD',17);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (885613,'Franklin_Oaklyn','Computer_Science','Senior',22);
INSERT INTO `` (`sid`,`sname`,`major`,`s_level`,`age`) VALUES (912912,'Dennis_Charles','Computer_Science','Freshman',23);
