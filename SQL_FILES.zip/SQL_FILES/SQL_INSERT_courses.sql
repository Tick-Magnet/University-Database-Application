/*
-- Query: SELECT * FROM university_data.courses
-- Date: 2021-11-15 10:24
*/
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 101','Intro to Computer Science','9:00-9:50','121',258852,50);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 102','Intro to Java','11:00-11:50','121',258852,50);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 103','Discrete Mathematics','10:00-10:50','123',258852,50);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 150','Intro to Python','8:00-8:50','291',455566,20);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 151','Honor\'s Computer Science','1:00-2:15','212',455566,2);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('CS 430','Database Systems','2:00-3:15','300',100100,10);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('MATH 150','Calculus','4:00-4:50','300',482259,300);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('MATH 221','Linear Algebra','9:00-9:50','483',482259,30);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('MATH 250','Calculus II','1:00-2:00','141',482259,200);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('PS 101','Intro to Power','9:00-9:50','401',149200,13);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('PS 102','Intro to Propaganda','10:00-10:50','053',149200,13);
INSERT INTO `` (`cid`,`cname`,`meets_at`,`room`,`fid`,`slimit`) VALUES ('PS 150','Intro to Geopolitics','2:00-3:15','10',149200,100);
