/*
-- Query: SELECT * FROM university_data.faculty
-- Date: 2021-11-15 10:25
*/
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (100001,'Garth_Caiden',1);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (100100,'Dunren_Che',7);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (123456,'Floella_Lee',6);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (130000,'Panama_Smith',12);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (147258,'Brittany_Brandee',12);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (149200,'Susa_Artaxerxes',27);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (231231,'Yazmin',7);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (231564,'Devereux_Paige',24);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (258852,'Lynette_Henrietta',7);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (265265,'Abraham_Bows',9);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (444444,'Damian_Seth',20);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (455566,'Alaiya_Franny',7);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (468597,'Brynne_Isabella',9);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (482259,'Douglas_Breann',17);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (566556,'Darcie_Genette',7);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (622558,'Dione_Nolene',3);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (862593,'Godfrey_Idella',18);
INSERT INTO `` (`fid`,`fname`,`deptid`) VALUES (898989,'Orpha_Celandine',7);
