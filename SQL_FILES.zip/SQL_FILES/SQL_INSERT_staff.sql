/*
-- Query: SELECT * FROM university_data.staff
-- Date: 2021-11-15 10:26
*/
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1001,'Leland_Luther',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1002,'Nowell_Bud',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1003,'Birdly_Loped',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1010,'Lois_Mallory',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1011,'Kaydence_Colin',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1020,'Solane_Posie',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1021,'Edwina_Robina',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1042,'Unity_Kali',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1050,'Lacey_Edythe',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1051,'Phebe_Justy',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1093,'Janis_Tania',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1190,'Bret_Barbra',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1191,'Clare Kurtis',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1192,'Jessamyn_Jenna',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1311,'Edwina_Robina',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (1420,'Hattie_Deanne',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2001,'Tillie_Christian',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2002,'Audie_Marcelyn',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2003,'Kathie_Marissa',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2010,'Wilton_Everleigh',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2011,'Max_Elis',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (2030,'Lois_Christy',0);
INSERT INTO `` (`sid`,`sname`,`deptid`) VALUES (962443,'Cherryl_Rudy',7);
