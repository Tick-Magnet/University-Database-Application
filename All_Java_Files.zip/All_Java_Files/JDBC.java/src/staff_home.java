import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.sql.*;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.DropMode;


public class staff_home extends JFrame {

	private JPanel contentPane;
	private JLayeredPane LayeredDeletePane;
	private JLayeredPane layeredStaffPane;
	private JLayeredPane layeredAddPane;
	private JLayeredPane LayeredUpdatePane;
	
	
	//Add
	private static JTextField course_id;
	private static JTextField course_name;
	private static JTextField course_time;
	private static JTextField course_room;
	private static JTextField course_fid;
	private static JTextField course_limit;
	private static JTextField department_name;
	private static JTextField department_id;
	private static JTextField department_ID;
	private static JTextField faculty_name;
	private static JTextField faculty_ID;
	private static JTextField staff_id;
	private static JTextField staff_name;
	private static JTextField Department_id;
	private static JTextField age;
	private static JTextField student_year;
	private static JTextField major;
	private static JTextField student_name;
	private static JTextField student_id;
	private static JTextField student_ID;
	private static JTextField course_ID;
	private static JTextField exam_one;
	private static JTextField exam_two;
	private static JTextField final_exam;

	
	//Delete
	private static JTextField dlt_course_id;
	private static JTextField dtl_course_name;
	private static JTextField dtl_time;
	private static JTextField dtl_room;
	private static JTextField dtl_faculty_id;
	private static JTextField dtl_limit;
	private static JTextField dlt_department_name;
	private static JTextField dlt_department_id;
	private static JTextField unenroll_sid;
	private static JTextField unenroll_cid;
	private static JTextField unenroll_exam1;
	private static JTextField unenroll_exam2;
	private static JTextField unenroll_final;
	private static JTextField delete_fid;
	private static JTextField delete_fname;
	private static JTextField delete_deptid;
	private static JTextField remove_department_id;
	private static JTextField remove_staff_name;
	private static JTextField remove_staff_id;
	private static JTextField delete_sid;
	private static JTextField delete_sname;
	private static JTextField delete_major;
	private static JTextField delete_s_level;
	private static JTextField delete_age;
	private static JTextField old_course_id;
	private static JTextField old_course_name;
	private static JTextField old_meeting_time;
	private static JTextField old_room;
	private static JTextField old_faculty_id;
	private static JTextField old_student_limit;
	private static JTextField new_meeting_time;
	private static JTextField new_course_name;
	private static JTextField new_course_id;
	private static JTextField new_room;
	private static JTextField new_faculty_id;
	private static JTextField new_student_limit;
	private static JTextField old_dept_id;
	private static JTextField old_dept_name;
	private static JTextField new_dept_name;
	private static JTextField new_dept_id;
	private static JTextField old_final_exam;
	private static JTextField old_exam_two;
	private static JTextField old_exam_one;
	private static JTextField old_course_ID;
	private static JTextField old_student_id;
	private static JTextField new_student_id;
	private static JTextField new_course_ID;
	private static JTextField new_exam_one;
	private static JTextField new_exam_two;
	private static JTextField new_final_exam;
	private static JTextField new_staff_id;
	private static JTextField new_staff_name;
	private static JTextField new_dept_ID;
	private static JTextField old_dept_ID;
	private static JTextField old_staff_name;
	private static JTextField old_staff_id;
	private static JTextField new_faculty_ID;
	private static JTextField new_faculty_name;
	private static JTextField new_department_id;
	private static JTextField old_department_id;
	private static JTextField old_faculty_name;
	private static JTextField old_faculty_ID;
	private static JTextField new_student_ID;
	private static JTextField new_student_name;
	private static JTextField new_major;
	private static JTextField new_student_year;
	private static JTextField new_age;
	private static JTextField old_student_ID;
	private static JTextField old_student_name;
	private static JTextField old_major;
	private static JTextField old_student_year;
	private static JTextField old_age;

	

	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					staff_home frame = new staff_home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	
	//Panel Switching Content :( It never wants to work right.
	
	public void switchPanels(JPanel panel) {
		layeredStaffPane.removeAll();
		layeredStaffPane.add(panel);
		layeredStaffPane.repaint();
		layeredStaffPane.revalidate();
	}
	
	public void switchAddPanels(JPanel panel) {
		layeredAddPane.removeAll();
		layeredAddPane.add(panel);
		layeredAddPane.repaint();
		layeredAddPane.revalidate();
	}
	
	public void switchDeletePanels(JPanel panel) {
		LayeredDeletePane.removeAll();
		LayeredDeletePane.add(panel);
		LayeredDeletePane.repaint();
		LayeredDeletePane.revalidate();
	}
	
	public void switchUpdatePanels(JPanel panel) {
		LayeredUpdatePane.removeAll();
		LayeredUpdatePane.add(panel);
		LayeredUpdatePane.repaint();
		LayeredUpdatePane.revalidate();
	}
	
	
	
	
	
	////The Following are Functions to Add data to the database.
	//Add New Course!
	static void addCourse(){
		
		try {
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
					
			String query = "INSERT INTO courses (cid, cname, meets_at, room, fid, slimit) values (?,?,?,?,?,?)";
			
			PreparedStatement pst = con.prepareStatement(query);	
			
			pst.setString(1, course_id.getText());
			pst.setString(2, course_name.getText());
			pst.setString(3, course_time.getText());
			pst.setInt(4,Integer.parseInt(course_room.getText()));
			pst.setInt(5,Integer.parseInt(course_fid.getText()));
			pst.setInt(6,Integer.parseInt(course_limit.getText()));	
			
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "The Course Database has been updated!");	
			return;
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "The Course Database failed to update.");
			return;
		}
		
	}
	
	//Add New Department!
	static void addDepartment(){
			
			try {
				
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				String query = "INSERT INTO department (did, dname) values (?,?)";
				
				PreparedStatement pst = con.prepareStatement(query);	
				
				pst.setInt(1,Integer.parseInt(department_id.getText()));
				pst.setString(2, department_name.getText());
				
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "The Department Database has been updated!");	
				return;
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Department Database failed to update.");
				return;
			}	
		}
	
	//Add New Faculty!
	static void addFaculty(){
				
				try {
					
					//SQL Initialization 
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
					
					String query = "INSERT INTO faculty (fid, fname, deptid) values (?,?,?)";
					
					PreparedStatement pst = con.prepareStatement(query);	
					
					pst.setInt(1,Integer.parseInt(faculty_ID.getText()));
					pst.setString(2, faculty_name.getText());
					pst.setInt(3,Integer.parseInt(department_ID.getText()));
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "The Faculty Database has been updated!");	
					return;
					
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "The Faculty Database failed to update.");
					return;
				}	
			}
	
		//Add Staff Department!
		static void addStaff(){
					
					try {
			
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						String query = "INSERT INTO staff (sid, sname, deptid) values (?,?,?)";
						
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(staff_id.getText()));
						pst.setString(2, staff_name.getText());
						pst.setInt(3,Integer.parseInt(Department_id.getText()));
						
						pst.executeUpdate();
						JOptionPane.showMessageDialog(null, "The Staff Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Staff Database failed to update.");
						return;
					}	
				}
	
		//Add New Course!
		static void addStudent(){
			
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
				String query = "INSERT INTO students (sid, sname, major, s_level, age) values (?,?,?,?,?)";
				
				PreparedStatement pst = con.prepareStatement(query);	
				
				pst.setInt(1,Integer.parseInt(student_id.getText()));
				pst.setString(2, student_name.getText());
				pst.setString(3, major.getText());
				pst.setString(4, student_year.getText());
				pst.setInt(5,Integer.parseInt(age.getText()));
				
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "The Student Database has been updated!");	
				return;
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Student Database failed to update.");
				return;
			}
			
		}
	
		//Enroll a Student!
		static void enroll(){
			
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
				String query = "INSERT INTO enrolled (sid, cid, exam1, exam2, final) values (?,?,?,?,?)";
				
				PreparedStatement pst = con.prepareStatement(query);	
		
				pst.setInt(1,Integer.parseInt(student_ID.getText()));
				pst.setString(2, course_ID.getText());
				pst.setInt(3,Integer.parseInt(exam_one.getText()));	
				pst.setInt(4,Integer.parseInt(exam_two.getText()));	
				pst.setInt(5,Integer.parseInt(final_exam.getText()));	
				
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "The Enrollment Database has been updated!");	
				return;
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Enrollment Database failed to update.");
				return;
			}
			
		}
		
		
		
		
		
		
		
		
		
		
		////The Following are Functions to Remove data to the database.
		
		//Delete a Course.
		static void delete_course(){
			
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
				String query = "DELETE FROM courses WHERE cid = ? AND cname = ? AND meets_at = ? AND room = ? AND fid = ? AND slimit = ?"; 
				PreparedStatement pst = con.prepareStatement(query);	
				
				pst.setString(1, dlt_course_id.getText());
				pst.setString(2, dtl_course_name.getText());
				pst.setString(3, dtl_time.getText());
				pst.setInt(4,Integer.parseInt(dtl_room.getText()));
				pst.setInt(5,Integer.parseInt(dtl_faculty_id.getText()));
				pst.setInt(6,Integer.parseInt(dtl_limit.getText()));	
				
				JOptionPane.showMessageDialog(null, pst);	
				
				pst.executeUpdate();
				
				JOptionPane.showMessageDialog(null, "The Course Database has been updated!");	
				return;
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Course Database failed to update.");
				return;
			}
			
		}
		
		//Delete a Database.
				static void delete_database(){
					
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "DELETE FROM department WHERE did = ? AND dname = ?"; 
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(dlt_department_id.getText()));
						pst.setString(2, dlt_department_name.getText());
			
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Department Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Department Database failed to update.");
						return;
					}
					
				}
				
				//Delete Enrolled
				static void delete_enrolled(){
					
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "DELETE FROM enrolled WHERE sid = ? AND cid = ? AND exam1 = ? AND exam2 = ? AND final = ?"; 
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(unenroll_sid.getText()));
						pst.setString(2, unenroll_cid.getText());
						pst.setInt(3,Integer.parseInt(unenroll_exam1.getText()));
						pst.setInt(4,Integer.parseInt(unenroll_exam2.getText()));
						pst.setInt(5,Integer.parseInt(unenroll_final.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Enrolled Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Enrolled Database failed to update.");
						return;
					}
					
				}
		
				//Delete a Faculty Member.
				static void delete_faculty(){
					
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "DELETE FROM faculty WHERE fid = ? AND fname = ? AND deptid = ?"; 
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(delete_fid.getText()));
						pst.setString(2, delete_fname.getText());
						pst.setInt(3,Integer.parseInt(delete_deptid.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Enrolled Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Enrolled Database failed to update.");
						return;
					}
					
				}
				
				//Delete a Staff Member.
				static void delete_staff(){
					
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "DELETE FROM staff WHERE sid = ? AND sname = ? AND deptid = ?"; 
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(remove_staff_id.getText()));
						pst.setString(2, remove_staff_name.getText());
						pst.setInt(3,Integer.parseInt(remove_department_id.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Staff Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Staff Database failed to update.");
						return;
					}
					
				}
				
				
				//Delete a Student.
				static void delete_student(){
					
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "DELETE FROM students WHERE sid = ? AND sname = ? AND major = ? AND s_level = ? AND age = ?"; 
						PreparedStatement pst = con.prepareStatement(query);	
						
						pst.setInt(1,Integer.parseInt(delete_sid.getText()));
						pst.setString(2, delete_sname.getText());
						pst.setString(3, delete_major.getText());
						pst.setString(4, delete_s_level.getText());
						pst.setInt(5,Integer.parseInt(delete_age.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Student Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Student Database failed to update.");
						return;
					}
					
				}
				
				
				
				
				
				
				
				
				//// UPDATE DATABASE CONTENT!!!
				
				//Update Courses				
				static void update_courses() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE courses "
								+ " SET cid = ?, cname = ?, meets_at = ?, room = ?, fid = ?, slimit = ? "
								+ " WHERE cid = ? AND cname = ? AND meets_at = ? AND room = ? AND fid = ? AND slimit = ?"; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setString(1, new_course_id.getText());
						pst.setString(2, new_course_name.getText());
						pst.setString(3, new_meeting_time.getText());
						pst.setInt(4, Integer.parseInt(new_room.getText()));
						pst.setInt(5,Integer.parseInt(new_faculty_id.getText()));
						pst.setInt(6,Integer.parseInt(new_student_limit.getText()));
						
						//Old
						pst.setString(7, old_course_id.getText());
						pst.setString(8, old_course_name.getText());
						pst.setString(9, old_meeting_time.getText());
						pst.setInt(10,Integer.parseInt(old_room.getText()));
						pst.setInt(11,Integer.parseInt(old_faculty_id.getText()));
						pst.setInt(12, Integer.parseInt(old_student_limit.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Course Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Course Database failed to update.");
						return;
					}
				}
				
				
				//Update Department
				static void update_department() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE department "
								+ " SET did = ?, dname = ? "
								+ " WHERE did = ? AND dname = ? "; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setInt(1, Integer.parseInt(new_dept_id.getText()));
						pst.setString(2, new_dept_name.getText());

						
						//Old
						pst.setInt(3, Integer.parseInt(old_dept_id.getText()));
						pst.setString(4, old_dept_name.getText());
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Department Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Department Database failed to update.");
						return;
					}
				}
				
				//Update Enrolled
				static void update_enrolled() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE enrolled "
								+ " SET sid = ?, cid = ?, exam1 = ?, exam2 = ?, final = ? "
								+ " WHERE sid = ? AND cid = ? AND exam1 = ? AND exam2 = ? AND final = ? "; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setInt(1, Integer.parseInt(new_student_id.getText()));
						pst.setString(2, new_course_ID.getText());
						pst.setInt(3, Integer.parseInt(new_exam_one.getText()));
						pst.setInt(4, Integer.parseInt(new_exam_two.getText()));
						pst.setInt(5, Integer.parseInt(new_final_exam.getText()));

						
						//Old
						pst.setInt(6, Integer.parseInt(old_student_id.getText()));
						pst.setString(7, old_course_ID.getText());
						pst.setInt(8, Integer.parseInt(old_exam_one.getText()));
						pst.setInt(9, Integer.parseInt(old_exam_two.getText()));
						pst.setInt(10, Integer.parseInt(old_final_exam.getText()));
						
						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Enrolled Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Enrolled Database failed to update.");
						return;
					}
				}
				
				
				//Update Staff
				static void update_staff() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE staff "
								+ " SET sid = ?, sname = ?, deptid = ? "
								+ " WHERE sid = ? AND sname = ? AND deptid = ? "; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setInt(1, Integer.parseInt(new_staff_id.getText()));
						pst.setString(2, new_staff_name.getText());
						pst.setInt(3, Integer.parseInt(new_dept_ID.getText()));
		
						//Old
						pst.setInt(4, Integer.parseInt(old_staff_id.getText()));
						pst.setString(5, old_staff_name.getText());
						pst.setInt(6, Integer.parseInt(old_dept_ID.getText()));

						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Staff Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Staff Database failed to update.");
						return;
					}
				}
				
				
				//Update Faculty
				static void update_faculty() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE faculty "
								+ " SET fid = ?, fname = ?, deptid = ? "
								+ " WHERE fid = ? AND fname = ? AND deptid = ? "; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setInt(1, Integer.parseInt(new_faculty_ID.getText()));
						pst.setString(2, new_faculty_name.getText());
						pst.setInt(3, Integer.parseInt(new_department_id.getText()));
		
						//Old
						pst.setInt(4, Integer.parseInt(old_faculty_ID.getText()));
						pst.setString(5, old_faculty_name.getText());
						pst.setInt(6, Integer.parseInt(old_department_id.getText()));

						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Faculty Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Faculty Database failed to update.");
						return;
					}
				}
				
				
				//Update Students
				static void update_students() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
								
						String query = "UPDATE students "
								+ " SET sid = ?, sname = ?, major = ?, s_level = ?, age = ? "
								+ " WHERE sid = ? AND sname = ? AND major = ? AND s_level = ? AND age = ? "; 
			
						PreparedStatement pst = con.prepareStatement(query);	
						
						//New
						pst.setInt(1, Integer.parseInt(new_student_ID.getText()));
						pst.setString(2, new_student_name.getText());
						pst.setString(3, new_major.getText());
						pst.setString(4, new_student_year.getText());
						pst.setInt(5, Integer.parseInt(new_age.getText()));
						
						//Old
						pst.setInt(6, Integer.parseInt(old_student_ID.getText()));
						pst.setString(7, old_student_name.getText());
						pst.setString(8, old_major.getText());
						pst.setString(9, old_student_year.getText());
						pst.setInt(10, Integer.parseInt(old_age.getText()));
		

						pst.executeUpdate();
						
						JOptionPane.showMessageDialog(null, "The Student Database has been updated!");	
						return;
						
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "The Student Database failed to update.");
						return;
					}
				}
				
				
		
	/**
	 * Create the frame.
	 */
	
	public staff_home() throws Exception{
		setResizable(false);
		
		
		getContentPane().setForeground(new Color(0, 0, 0));
		setBackground(new Color(192, 192, 192));
		getContentPane().setBackground(new Color(192, 192, 192));
		getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		setBounds(100, 100, 890, 597);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		
		
		//Header
		JPanel header = new JPanel();
		header.setBounds(0, 0, 876, 67);
		getContentPane().add(header);
		
		JLabel lblNewLabel = new JLabel("Staff Control Panel");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 50));
		header.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setBackground(new Color(128, 0, 0));
		
		
		//LayeredPane
		layeredStaffPane = new JLayeredPane();
		layeredStaffPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		layeredStaffPane.setBounds(130, 106, 736, 400);
		getContentPane().add(layeredStaffPane);
		layeredStaffPane.setLayout(new CardLayout(0, 0));
		
		JPanel panel_add = new JPanel();
		layeredStaffPane.add(panel_add, "name_54550758337000");
		panel_add.setLayout(null);
		
		
		//Panels
		JLabel lblNewLabel_1 = new JLabel("Add Content to Database:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 10, 162, 21);
		panel_add.add(lblNewLabel_1);
		
		layeredAddPane = new JLayeredPane();
		layeredAddPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		layeredAddPane.setBounds(157, 10, 565, 370);
		panel_add.add(layeredAddPane);
		layeredAddPane.setLayout(new CardLayout(0, 0));
		
		JPanel panel_add_courses = new JPanel();
		layeredAddPane.add(panel_add_courses, "name_64753361573300");
		panel_add_courses.setLayout(null);
		
		
		
		JLabel lblNewLabel_6 = new JLabel("Create a Course:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6.setBounds(10, 10, 353, 23);
		panel_add_courses.add(lblNewLabel_6);
		
		JLabel lblNewLabel_6_1 = new JLabel("Course ID:");
		lblNewLabel_6_1.setBounds(10, 49, 78, 13);
		panel_add_courses.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_1_1 = new JLabel("Course Name:");
		lblNewLabel_6_1_1.setBounds(10, 74, 109, 13);
		panel_add_courses.add(lblNewLabel_6_1_1);
		
		JLabel lblNewLabel_6_1_1_1 = new JLabel("Meeting Time:");
		lblNewLabel_6_1_1_1.setBounds(10, 97, 109, 13);
		panel_add_courses.add(lblNewLabel_6_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1 = new JLabel("Room:");
		lblNewLabel_6_1_1_1_1.setBounds(10, 120, 78, 13);
		panel_add_courses.add(lblNewLabel_6_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_1_1_1_1.setBounds(10, 143, 109, 13);
		panel_add_courses.add(lblNewLabel_6_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1 = new JLabel("Student Limit:");
		lblNewLabel_6_1_1_1_1_1_1.setBounds(10, 166, 109, 13);
		panel_add_courses.add(lblNewLabel_6_1_1_1_1_1_1);
		
		course_id = new JTextField();
		course_id.setBounds(138, 43, 215, 19);
		panel_add_courses.add(course_id);
		course_id.setColumns(10);
		
		course_name = new JTextField();
		course_name.setColumns(10);
		course_name.setBounds(138, 68, 215, 19);
		panel_add_courses.add(course_name);
		
		course_time = new JTextField();
		course_time.setColumns(10);
		course_time.setBounds(138, 91, 215, 19);
		panel_add_courses.add(course_time);
		
		course_room = new JTextField();
		course_room.setColumns(10);
		course_room.setBounds(138, 114, 215, 19);
		panel_add_courses.add(course_room);
		
		course_fid = new JTextField();
		course_fid.setColumns(10);
		course_fid.setBounds(138, 137, 215, 19);
		panel_add_courses.add(course_fid);
		
		course_limit = new JTextField();
		course_limit.setColumns(10);
		course_limit.setBounds(138, 160, 215, 19);
		panel_add_courses.add(course_limit);
		
		JButton create_course = new JButton("Create");
		create_course.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					addCourse();
			}
		});
		create_course.setBounds(138, 189, 96, 21);
		panel_add_courses.add(create_course);
		
		JPanel panel_add_department = new JPanel();
		layeredAddPane.add(panel_add_department, "name_64753377208600");
		panel_add_department.setLayout(null);
		
		JButton create_department = new JButton("Create");
		create_department.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addDepartment();
			}
		});
		create_department.setBounds(181, 97, 96, 21);
		panel_add_department.add(create_department);
		
		department_name = new JTextField();
		department_name.setColumns(10);
		department_name.setBounds(181, 68, 215, 19);
		panel_add_department.add(department_name);
		
		department_id = new JTextField();
		department_id.setColumns(10);
		department_id.setBounds(181, 43, 215, 19);
		panel_add_department.add(department_id);
		
		JLabel lblNewLabel_6_1_2 = new JLabel("Department ID:");
		lblNewLabel_6_1_2.setBounds(10, 49, 134, 13);
		panel_add_department.add(lblNewLabel_6_1_2);
		
		JLabel lblNewLabel_6_1_1_2 = new JLabel("Department Name:");
		lblNewLabel_6_1_1_2.setBounds(10, 74, 134, 13);
		panel_add_department.add(lblNewLabel_6_1_1_2);
		
		JLabel lblNewLabel_6_2 = new JLabel("Create a Department:");
		lblNewLabel_6_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_2.setBounds(10, 10, 353, 23);
		panel_add_department.add(lblNewLabel_6_2);
		
		JPanel panel_add_enrolled = new JPanel();
		layeredAddPane.add(panel_add_enrolled, "name_64753391191800");
		panel_add_enrolled.setLayout(null);
		
		JLabel lblNewLabel_6_5 = new JLabel("Enrollment:");
		lblNewLabel_6_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_5.setBounds(10, 10, 353, 23);
		panel_add_enrolled.add(lblNewLabel_6_5);
		
		JLabel lblNewLabel_6_1_5 = new JLabel("Student ID:");
		lblNewLabel_6_1_5.setBounds(10, 49, 78, 13);
		panel_add_enrolled.add(lblNewLabel_6_1_5);
		
		student_ID = new JTextField();
		student_ID.setColumns(10);
		student_ID.setBounds(138, 43, 215, 19);
		panel_add_enrolled.add(student_ID);
		
		JLabel lblNewLabel_6_1_1_5 = new JLabel("Course ID");
		lblNewLabel_6_1_1_5.setBounds(10, 74, 109, 13);
		panel_add_enrolled.add(lblNewLabel_6_1_1_5);
		
		course_ID = new JTextField();
		course_ID.setColumns(10);
		course_ID.setBounds(138, 68, 215, 19);
		panel_add_enrolled.add(course_ID);
		
		exam_one = new JTextField();
		exam_one.setColumns(10);
		exam_one.setBounds(138, 91, 215, 19);
		panel_add_enrolled.add(exam_one);
		
		JLabel lblNewLabel_6_1_1_1_4 = new JLabel("Exam One:");
		lblNewLabel_6_1_1_1_4.setBounds(10, 97, 109, 13);
		panel_add_enrolled.add(lblNewLabel_6_1_1_1_4);
		
		JLabel lblNewLabel_6_1_1_1_1_3 = new JLabel("Exame Two:");
		lblNewLabel_6_1_1_1_1_3.setBounds(10, 120, 78, 13);
		panel_add_enrolled.add(lblNewLabel_6_1_1_1_1_3);
		
		exam_two = new JTextField();
		exam_two.setColumns(10);
		exam_two.setBounds(138, 114, 215, 19);
		panel_add_enrolled.add(exam_two);
		
		final_exam = new JTextField();
		final_exam.setColumns(10);
		final_exam.setBounds(138, 137, 215, 19);
		panel_add_enrolled.add(final_exam);
		
		JLabel lblNewLabel_6_1_1_1_1_1_3 = new JLabel("Final Exam:");
		lblNewLabel_6_1_1_1_1_1_3.setBounds(10, 143, 109, 13);
		panel_add_enrolled.add(lblNewLabel_6_1_1_1_1_1_3);
		
		JButton create_course_1 = new JButton("Enroll");
		create_course_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enroll();
			}
		});
		create_course_1.setBounds(138, 166, 96, 21);
		panel_add_enrolled.add(create_course_1);
		
		JPanel panel_add_faculty = new JPanel();
		layeredAddPane.add(panel_add_faculty, "name_64753402917600");
		panel_add_faculty.setLayout(null);
		
		department_ID = new JTextField();
		department_ID.setColumns(10);
		department_ID.setBounds(138, 91, 215, 19);
		panel_add_faculty.add(department_ID);
		
		faculty_name = new JTextField();
		faculty_name.setColumns(10);
		faculty_name.setBounds(138, 68, 215, 19);
		panel_add_faculty.add(faculty_name);
		
		faculty_ID = new JTextField();
		faculty_ID.setColumns(10);
		faculty_ID.setBounds(138, 43, 215, 19);
		panel_add_faculty.add(faculty_ID);
		
		JLabel lblNewLabel_6_3 = new JLabel("Add a new faculty member:");
		lblNewLabel_6_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_3.setBounds(10, 10, 353, 23);
		panel_add_faculty.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_1_3 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_3.setBounds(10, 49, 78, 13);
		panel_add_faculty.add(lblNewLabel_6_1_3);
		
		JLabel lblNewLabel_6_1_1_3 = new JLabel("Faculty Name:");
		lblNewLabel_6_1_1_3.setBounds(10, 74, 109, 13);
		panel_add_faculty.add(lblNewLabel_6_1_1_3);
		
		JLabel lblNewLabel_6_1_1_1_2 = new JLabel("Department ID:");
		lblNewLabel_6_1_1_1_2.setBounds(10, 97, 109, 13);
		panel_add_faculty.add(lblNewLabel_6_1_1_1_2);
		
		
		//Add New Faculty
		
		JButton Add_Faculty = new JButton("Add");
		Add_Faculty.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addFaculty();
			}
		});
		
		
		Add_Faculty.setBounds(138, 120, 96, 21);
		panel_add_faculty.add(Add_Faculty);
		
		JPanel panel_add_staff = new JPanel();
		layeredAddPane.add(panel_add_staff, "name_64753415872300");
		panel_add_staff.setLayout(null);
		
		staff_id = new JTextField();
		staff_id.setColumns(10);
		staff_id.setBounds(138, 43, 215, 19);
		panel_add_staff.add(staff_id);
		
		JLabel lblNewLabel_6_3_1 = new JLabel("Add a new staff member:");
		lblNewLabel_6_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_3_1.setBounds(10, 10, 353, 23);
		panel_add_staff.add(lblNewLabel_6_3_1);
		
		JLabel text1 = new JLabel("Staff ID:");
		text1.setBounds(10, 49, 78, 13);
		panel_add_staff.add(text1);
		
		JLabel text2 = new JLabel("Staff Name:");
		text2.setBounds(10, 74, 109, 13);
		panel_add_staff.add(text2);
		
		staff_name = new JTextField();
		staff_name.setColumns(10);
		staff_name.setBounds(138, 68, 215, 19);
		panel_add_staff.add(staff_name);
		
		Department_id = new JTextField();
		Department_id.setColumns(10);
		Department_id.setBounds(138, 91, 215, 19);
		panel_add_staff.add(Department_id);
		
		JLabel text3 = new JLabel("Department ID:");
		text3.setBounds(10, 97, 109, 13);
		panel_add_staff.add(text3);
		
		
		//Add Staff
		JButton Add_Staff = new JButton("Add");
		Add_Staff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addStaff();
			}
		});
		
		
		Add_Staff.setBounds(138, 120, 96, 21);
		panel_add_staff.add(Add_Staff);
		
		JPanel panel_add_students = new JPanel();
		layeredAddPane.add(panel_add_students, "name_64753429373900");
		panel_add_students.setLayout(null);
		
		JLabel lblNewLabel_6_4 = new JLabel("Add a Student:");
		lblNewLabel_6_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_4.setBounds(10, 10, 353, 23);
		panel_add_students.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_1_4 = new JLabel("Student ID:");
		lblNewLabel_6_1_4.setBounds(10, 49, 78, 13);
		panel_add_students.add(lblNewLabel_6_1_4);
		
		JLabel lblNewLabel_6_1_1_4 = new JLabel("Student Name:");
		lblNewLabel_6_1_1_4.setBounds(10, 74, 109, 13);
		panel_add_students.add(lblNewLabel_6_1_1_4);
		
		JLabel lblNewLabel_6_1_1_1_3 = new JLabel("Major:");
		lblNewLabel_6_1_1_1_3.setBounds(10, 97, 109, 13);
		panel_add_students.add(lblNewLabel_6_1_1_1_3);
		
		JLabel lblNewLabel_6_1_1_1_1_2 = new JLabel("Student Year:");
		lblNewLabel_6_1_1_1_1_2.setBounds(10, 120, 78, 13);
		panel_add_students.add(lblNewLabel_6_1_1_1_1_2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2 = new JLabel("Age:");
		lblNewLabel_6_1_1_1_1_1_2.setBounds(10, 143, 109, 13);
		panel_add_students.add(lblNewLabel_6_1_1_1_1_1_2);
		
		age = new JTextField();
		age.setColumns(10);
		age.setBounds(138, 137, 215, 19);
		panel_add_students.add(age);
		
		student_year = new JTextField();
		student_year.setColumns(10);
		student_year.setBounds(138, 114, 215, 19);
		panel_add_students.add(student_year);
		
		major = new JTextField();
		major.setColumns(10);
		major.setBounds(138, 91, 215, 19);
		panel_add_students.add(major);
		
		student_name = new JTextField();
		student_name.setColumns(10);
		student_name.setBounds(138, 68, 215, 19);
		panel_add_students.add(student_name);
		
		student_id = new JTextField();
		student_id.setColumns(10);
		student_id.setBounds(138, 43, 215, 19);
		panel_add_students.add(student_id);
		
		
		//Add Student
		JButton add_student = new JButton("Add");
		add_student.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addStudent();
			}
		});
		
		
		
		add_student.setBounds(138, 166, 96, 23);
		panel_add_students.add(add_student);
		
		JButton btnAddCourses = new JButton("Courses");
		btnAddCourses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_courses);
			}
		});
		btnAddCourses.setBounds(10, 42, 137, 21);
		panel_add.add(btnAddCourses);
		
		JButton btnAddDepartment = new JButton("Department");
		btnAddDepartment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_department);
			}
		});
		btnAddDepartment.setBounds(10, 73, 137, 21);
		panel_add.add(btnAddDepartment);
		
		JButton btnEnrolled = new JButton("Enrolled");
		btnEnrolled.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_enrolled);
			}
		});
		btnEnrolled.setBounds(10, 104, 137, 21);
		panel_add.add(btnEnrolled);
		
		JButton btnFaculty = new JButton("Faculty");
		btnFaculty.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_faculty);
			}
		});
		btnFaculty.setBounds(10, 135, 137, 21);
		panel_add.add(btnFaculty);
		
		JButton btnStaff = new JButton("Staff");
		btnStaff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_staff);
			}
		});
		btnStaff.setBounds(10, 166, 137, 21);
		panel_add.add(btnStaff);
		
		JButton btnStudents = new JButton("Students");
		btnStudents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchAddPanels(panel_add_students);
			}
		});
		btnStudents.setBounds(10, 197, 137, 21);
		panel_add.add(btnStudents);
		
		JPanel panel_delete = new JPanel();
		layeredStaffPane.add(panel_delete, "name_54550778708500");
		panel_delete.setLayout(null);
		
		//Create layeredDeletePane
		LayeredDeletePane = new JLayeredPane();
		LayeredDeletePane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		LayeredDeletePane.setBounds(157, 10, 565, 370);
		panel_delete.add(LayeredDeletePane);
		LayeredDeletePane.setLayout(new CardLayout(0, 0));
		
		JLabel lblNewLabel_1_2 = new JLabel("Delete Database Content:");
		lblNewLabel_1_2.setBounds(10, 10, 162, 21);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel_delete.add(lblNewLabel_1_2);
		
		
		JPanel panel_delete_courses = new JPanel();
		panel_delete_courses.setLayout(null);
		LayeredDeletePane.add(panel_delete_courses, "name_76508115194300");
		
		JLabel lblNewLabel_6_6 = new JLabel("Delete a Course:");
		lblNewLabel_6_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6.setBounds(10, 10, 353, 23);
		panel_delete_courses.add(lblNewLabel_6_6);
		
		JLabel lblNewLabel_6_1_6 = new JLabel("Course ID:");
		lblNewLabel_6_1_6.setBounds(10, 49, 78, 13);
		panel_delete_courses.add(lblNewLabel_6_1_6);
		
		JLabel lblNewLabel_6_1_1_6 = new JLabel("Course Name:");
		lblNewLabel_6_1_1_6.setBounds(10, 74, 109, 13);
		panel_delete_courses.add(lblNewLabel_6_1_1_6);
		
		JLabel lblNewLabel_6_1_1_1_5 = new JLabel("Meeting Time:");
		lblNewLabel_6_1_1_1_5.setBounds(10, 97, 109, 13);
		panel_delete_courses.add(lblNewLabel_6_1_1_1_5);
		
		JLabel lblNewLabel_6_1_1_1_1_4 = new JLabel("Room:");
		lblNewLabel_6_1_1_1_1_4.setBounds(10, 120, 78, 13);
		panel_delete_courses.add(lblNewLabel_6_1_1_1_1_4);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_1_1_1_1_4.setBounds(10, 143, 109, 13);
		panel_delete_courses.add(lblNewLabel_6_1_1_1_1_1_4);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1_1 = new JLabel("Student Limit:");
		lblNewLabel_6_1_1_1_1_1_1_1.setBounds(10, 166, 109, 13);
		panel_delete_courses.add(lblNewLabel_6_1_1_1_1_1_1_1);
		
		dlt_course_id = new JTextField();
		dlt_course_id.setColumns(10);
		dlt_course_id.setBounds(138, 43, 215, 19);
		panel_delete_courses.add(dlt_course_id);
		
		dtl_course_name = new JTextField();
		dtl_course_name.setColumns(10);
		dtl_course_name.setBounds(138, 68, 215, 19);
		panel_delete_courses.add(dtl_course_name);
		
		dtl_time = new JTextField();
		dtl_time.setColumns(10);
		dtl_time.setBounds(138, 91, 215, 19);
		panel_delete_courses.add(dtl_time);
		
		dtl_room = new JTextField();
		dtl_room.setColumns(10);
		dtl_room.setBounds(138, 114, 215, 19);
		panel_delete_courses.add(dtl_room);
		
		dtl_faculty_id = new JTextField();
		dtl_faculty_id.setColumns(10);
		dtl_faculty_id.setBounds(138, 137, 215, 19);
		panel_delete_courses.add(dtl_faculty_id);
		
		dtl_limit = new JTextField();
		dtl_limit.setColumns(10);
		dtl_limit.setBounds(138, 160, 215, 19);
		panel_delete_courses.add(dtl_limit);
		
		
		
		//Delete Course
		JButton delete_course = new JButton("Delete");
		delete_course.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete_course();
			}
		});
		delete_course.setBounds(138, 189, 96, 21);
		panel_delete_courses.add(delete_course);
		
		JPanel panel_delete_department = new JPanel();
		panel_delete_department.setLayout(null);
		LayeredDeletePane.add(panel_delete_department, "name_77842074675300");
		
		
				
		
		
		//Delete Database
		JButton create_department_1 = new JButton("Delete");
		create_department_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete_database();
			}
		});
		create_department_1.setBounds(181, 97, 96, 21);
		panel_delete_department.add(create_department_1);
		
		dlt_department_name = new JTextField();
		dlt_department_name.setColumns(10);
		dlt_department_name.setBounds(181, 68, 215, 19);
		panel_delete_department.add(dlt_department_name);
		
		dlt_department_id = new JTextField();
		dlt_department_id.setColumns(10);
		dlt_department_id.setBounds(181, 43, 215, 19);
		panel_delete_department.add(dlt_department_id);
		
		JLabel lblNewLabel_6_1_2_1 = new JLabel("Department ID:");
		lblNewLabel_6_1_2_1.setBounds(10, 49, 134, 13);
		panel_delete_department.add(lblNewLabel_6_1_2_1);
		
		JLabel lblNewLabel_6_1_1_2_1 = new JLabel("Department Name:");
		lblNewLabel_6_1_1_2_1.setBounds(10, 74, 134, 13);
		panel_delete_department.add(lblNewLabel_6_1_1_2_1);
		
		JLabel lblNewLabel_6_2_1 = new JLabel("Delete a Department:");
		lblNewLabel_6_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_2_1.setBounds(10, 10, 353, 23);
		panel_delete_department.add(lblNewLabel_6_2_1);
		
		JPanel panel_delete_enrolled = new JPanel();
		LayeredDeletePane.add(panel_delete_enrolled, "name_20805644031100");
		panel_delete_enrolled.setLayout(null);
		
		JLabel lblNewLabel_6_6_1 = new JLabel("Unenroll:");
		lblNewLabel_6_6_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_1.setBounds(10, 10, 353, 23);
		panel_delete_enrolled.add(lblNewLabel_6_6_1);
		
		JLabel lblNewLabel_6_1_6_1 = new JLabel("Student ID:");
		lblNewLabel_6_1_6_1.setBounds(10, 49, 78, 13);
		panel_delete_enrolled.add(lblNewLabel_6_1_6_1);
		
		unenroll_sid = new JTextField();
		unenroll_sid.setColumns(10);
		unenroll_sid.setBounds(138, 43, 215, 19);
		panel_delete_enrolled.add(unenroll_sid);
		
		JLabel lblNewLabel_6_1_1_6_1 = new JLabel("Course ID:");
		lblNewLabel_6_1_1_6_1.setBounds(10, 74, 109, 13);
		panel_delete_enrolled.add(lblNewLabel_6_1_1_6_1);
		
		unenroll_cid = new JTextField();
		unenroll_cid.setColumns(10);
		unenroll_cid.setBounds(138, 68, 215, 19);
		panel_delete_enrolled.add(unenroll_cid);
		
		JLabel lblNewLabel_6_1_1_1_5_1 = new JLabel("Exam 1:");
		lblNewLabel_6_1_1_1_5_1.setBounds(10, 97, 109, 13);
		panel_delete_enrolled.add(lblNewLabel_6_1_1_1_5_1);
		
		unenroll_exam1 = new JTextField();
		unenroll_exam1.setColumns(10);
		unenroll_exam1.setBounds(138, 91, 215, 19);
		panel_delete_enrolled.add(unenroll_exam1);
		
		JLabel lblNewLabel_6_1_1_1_1_4_1 = new JLabel("Exam 2:");
		lblNewLabel_6_1_1_1_1_4_1.setBounds(10, 120, 78, 13);
		panel_delete_enrolled.add(lblNewLabel_6_1_1_1_1_4_1);
		
		unenroll_exam2 = new JTextField();
		unenroll_exam2.setColumns(10);
		unenroll_exam2.setBounds(138, 114, 215, 19);
		panel_delete_enrolled.add(unenroll_exam2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_1 = new JLabel("Final Exam:");
		lblNewLabel_6_1_1_1_1_1_4_1.setBounds(10, 143, 109, 13);
		panel_delete_enrolled.add(lblNewLabel_6_1_1_1_1_1_4_1);
		
		unenroll_final = new JTextField();
		unenroll_final.setColumns(10);
		unenroll_final.setBounds(138, 137, 215, 19);
		panel_delete_enrolled.add(unenroll_final);
		
		JButton delete_course_1 = new JButton("Unenroll");
		delete_course_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete_enrolled();
			}
		});
		delete_course_1.setBounds(138, 166, 96, 21);
		panel_delete_enrolled.add(delete_course_1);
		
		JPanel panel_delete_faculty = new JPanel();
		LayeredDeletePane.add(panel_delete_faculty, "name_20864126119700");
		panel_delete_faculty.setLayout(null);
		
		JLabel lblNewLabel_6_6_2 = new JLabel("Remove Faculty:");
		lblNewLabel_6_6_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_2.setBounds(10, 10, 353, 23);
		panel_delete_faculty.add(lblNewLabel_6_6_2);
		
		JLabel lblNewLabel_6_1_6_2 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_6_2.setBounds(10, 49, 78, 13);
		panel_delete_faculty.add(lblNewLabel_6_1_6_2);
		
		JLabel lblNewLabel_6_1_1_6_2 = new JLabel("Faculty Name:");
		lblNewLabel_6_1_1_6_2.setBounds(10, 74, 109, 13);
		panel_delete_faculty.add(lblNewLabel_6_1_1_6_2);
		
		delete_fid = new JTextField();
		delete_fid.setColumns(10);
		delete_fid.setBounds(138, 43, 215, 19);
		panel_delete_faculty.add(delete_fid);
		
		delete_fname = new JTextField();
		delete_fname.setColumns(10);
		delete_fname.setBounds(138, 68, 215, 19);
		panel_delete_faculty.add(delete_fname);
		
		delete_deptid = new JTextField();
		delete_deptid.setColumns(10);
		delete_deptid.setBounds(138, 91, 215, 19);
		panel_delete_faculty.add(delete_deptid);
		
		JLabel lblNewLabel_6_1_1_1_5_2 = new JLabel("Department ID:");
		lblNewLabel_6_1_1_1_5_2.setBounds(10, 97, 109, 13);
		panel_delete_faculty.add(lblNewLabel_6_1_1_1_5_2);
		
		
		
		JPanel panel_delete_staff = new JPanel();
		LayeredDeletePane.add(panel_delete_staff, "name_20870862950600");
		panel_delete_staff.setLayout(null);
		
		JLabel lblNewLabel_6_6_3 = new JLabel("Remove Staff:");
		lblNewLabel_6_6_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_3.setBounds(10, 10, 353, 23);
		panel_delete_staff.add(lblNewLabel_6_6_3);
		
		JLabel lblNewLabel_6_1_6_3 = new JLabel("Staff ID:");
		lblNewLabel_6_1_6_3.setBounds(10, 49, 78, 13);
		panel_delete_staff.add(lblNewLabel_6_1_6_3);
		
		JLabel lblNewLabel_6_1_1_6_3 = new JLabel("Staff Name:");
		lblNewLabel_6_1_1_6_3.setBounds(10, 74, 109, 13);
		panel_delete_staff.add(lblNewLabel_6_1_1_6_3);
		
		JLabel lblNewLabel_6_1_1_1_5_3 = new JLabel("Department ID:");
		lblNewLabel_6_1_1_1_5_3.setBounds(10, 97, 109, 13);
		panel_delete_staff.add(lblNewLabel_6_1_1_1_5_3);
		
		remove_department_id = new JTextField();
		remove_department_id.setColumns(10);
		remove_department_id.setBounds(138, 91, 215, 19);
		panel_delete_staff.add(remove_department_id);
		
		remove_staff_name = new JTextField();
		remove_staff_name.setColumns(10);
		remove_staff_name.setBounds(138, 68, 215, 19);
		panel_delete_staff.add(remove_staff_name);
		
		remove_staff_id = new JTextField();
		remove_staff_id.setColumns(10);
		remove_staff_id.setBounds(138, 43, 215, 19);
		panel_delete_staff.add(remove_staff_id);
		
		JButton delete_course_3 = new JButton("Remove");
		delete_course_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete_staff();
			}
		});
		delete_course_3.setBounds(138, 120, 96, 21);
		panel_delete_staff.add(delete_course_3);
		
		JPanel panel_delete_students = new JPanel();
		LayeredDeletePane.add(panel_delete_students, "name_20880333012700");
		panel_delete_students.setLayout(null);
		
		JLabel lblNewLabel_6_1_6_4 = new JLabel("Student ID:");
		lblNewLabel_6_1_6_4.setBounds(10, 49, 78, 13);
		panel_delete_students.add(lblNewLabel_6_1_6_4);
		
		delete_sid = new JTextField();
		delete_sid.setColumns(10);
		delete_sid.setBounds(138, 43, 215, 19);
		panel_delete_students.add(delete_sid);
		
		JLabel lblNewLabel_6_1_1_6_4 = new JLabel("Student Name:");
		lblNewLabel_6_1_1_6_4.setBounds(10, 74, 109, 13);
		panel_delete_students.add(lblNewLabel_6_1_1_6_4);
		
		delete_sname = new JTextField();
		delete_sname.setColumns(10);
		delete_sname.setBounds(138, 68, 215, 19);
		panel_delete_students.add(delete_sname);
		
		JLabel lblNewLabel_6_1_1_1_5_4 = new JLabel("Major:");
		lblNewLabel_6_1_1_1_5_4.setBounds(10, 97, 109, 13);
		panel_delete_students.add(lblNewLabel_6_1_1_1_5_4);
		
		delete_major = new JTextField();
		delete_major.setColumns(10);
		delete_major.setBounds(138, 91, 215, 19);
		panel_delete_students.add(delete_major);
		
		JLabel lblNewLabel_6_1_1_1_1_4_2 = new JLabel("Student Year:");
		lblNewLabel_6_1_1_1_1_4_2.setBounds(10, 120, 78, 13);
		panel_delete_students.add(lblNewLabel_6_1_1_1_1_4_2);
		
		delete_s_level = new JTextField();
		delete_s_level.setColumns(10);
		delete_s_level.setBounds(138, 114, 215, 19);
		panel_delete_students.add(delete_s_level);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_2 = new JLabel("Age:");
		lblNewLabel_6_1_1_1_1_1_4_2.setBounds(10, 143, 109, 13);
		panel_delete_students.add(lblNewLabel_6_1_1_1_1_1_4_2);
		
		delete_age = new JTextField();
		delete_age.setColumns(10);
		delete_age.setBounds(138, 137, 215, 19);
		panel_delete_students.add(delete_age);
		
		JButton delete_course_4 = new JButton("Delete");
		delete_course_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete_student();
			}
		});
		delete_course_4.setBounds(138, 166, 96, 21);
		panel_delete_students.add(delete_course_4);
		
		JLabel lblNewLabel_6_6_4 = new JLabel("Remove a student:");
		lblNewLabel_6_6_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_4.setBounds(10, 10, 353, 23);
		panel_delete_students.add(lblNewLabel_6_6_4);
		
		JPanel panel_update = new JPanel();
		layeredStaffPane.add(panel_update, "name_54550799468500");
		panel_update.setLayout(null);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Update Database Content:");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_1_1.setBounds(10, 10, 162, 21);
		panel_update.add(lblNewLabel_1_1_1);
		
	
		
		
		
		LayeredUpdatePane = new JLayeredPane();
		LayeredUpdatePane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		LayeredUpdatePane.setBounds(155, 10, 567, 376);
		panel_update.add(LayeredUpdatePane);
		LayeredUpdatePane.setLayout(new CardLayout(0, 0));
		
		JPanel update_course = new JPanel();
		LayeredUpdatePane.add(update_course, "name_17760184549600");
		update_course.setLayout(null);
		
		JLabel lblNewLabel_6_6_5 = new JLabel("Update a Course:");
		lblNewLabel_6_6_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5.setBounds(10, 10, 353, 23);
		update_course.add(lblNewLabel_6_6_5);
		
		JLabel lblNewLabel_6_1_6_5 = new JLabel("Course ID:");
		lblNewLabel_6_1_6_5.setBounds(10, 76, 78, 13);
		update_course.add(lblNewLabel_6_1_6_5);
		
		JLabel lblNewLabel_6_1_1_6_5 = new JLabel("Course Name:");
		lblNewLabel_6_1_1_6_5.setBounds(10, 101, 109, 13);
		update_course.add(lblNewLabel_6_1_1_6_5);
		
		JLabel lblNewLabel_6_1_1_1_5_5 = new JLabel("Meeting Time:");
		lblNewLabel_6_1_1_1_5_5.setBounds(10, 124, 109, 13);
		update_course.add(lblNewLabel_6_1_1_1_5_5);
		
		JLabel lblNewLabel_6_1_1_1_1_4_3 = new JLabel("Room:");
		lblNewLabel_6_1_1_1_1_4_3.setBounds(10, 147, 78, 13);
		update_course.add(lblNewLabel_6_1_1_1_1_4_3);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_3 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_1_1_1_1_4_3.setBounds(10, 170, 109, 13);
		update_course.add(lblNewLabel_6_1_1_1_1_1_4_3);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1_1_1 = new JLabel("Student Limit:");
		lblNewLabel_6_1_1_1_1_1_1_1_1.setBounds(10, 193, 109, 13);
		update_course.add(lblNewLabel_6_1_1_1_1_1_1_1_1);
		
		old_course_id = new JTextField();
		old_course_id.setColumns(10);
		old_course_id.setBounds(98, 70, 215, 19);
		update_course.add(old_course_id);
		
		old_course_name = new JTextField();
		old_course_name.setColumns(10);
		old_course_name.setBounds(98, 95, 215, 19);
		update_course.add(old_course_name);
		
		old_meeting_time = new JTextField();
		old_meeting_time.setColumns(10);
		old_meeting_time.setBounds(98, 118, 215, 19);
		update_course.add(old_meeting_time);
		
		old_room = new JTextField();
		old_room.setColumns(10);
		old_room.setBounds(98, 141, 215, 19);
		update_course.add(old_room);
		
		old_faculty_id = new JTextField();
		old_faculty_id.setColumns(10);
		old_faculty_id.setBounds(98, 164, 215, 19);
		update_course.add(old_faculty_id);
		
		old_student_limit = new JTextField();
		old_student_limit.setColumns(10);
		old_student_limit.setBounds(98, 187, 215, 19);
		update_course.add(old_student_limit);
		
		JButton delete_course_5 = new JButton("Update");
		delete_course_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_courses();
			}
		});
		delete_course_5.setBounds(457, 216, 96, 21);
		update_course.add(delete_course_5);
		
		new_meeting_time = new JTextField();
		new_meeting_time.setColumns(10);
		new_meeting_time.setBounds(338, 118, 215, 19);
		update_course.add(new_meeting_time);
		
		new_course_name = new JTextField();
		new_course_name.setColumns(10);
		new_course_name.setBounds(338, 95, 215, 19);
		update_course.add(new_course_name);
		
		new_course_id = new JTextField();
		new_course_id.setColumns(10);
		new_course_id.setBounds(338, 70, 215, 19);
		update_course.add(new_course_id);
		
		new_room = new JTextField();
		new_room.setColumns(10);
		new_room.setBounds(338, 141, 215, 19);
		update_course.add(new_room);
		
		new_faculty_id = new JTextField();
		new_faculty_id.setColumns(10);
		new_faculty_id.setBounds(338, 164, 215, 19);
		update_course.add(new_faculty_id);
		
		new_student_limit = new JTextField();
		new_student_limit.setColumns(10);
		new_student_limit.setBounds(338, 187, 215, 19);
		update_course.add(new_student_limit);
		
		JLabel lblNewLabel_6_1_6_5_1 = new JLabel("Old Course Info:");
		lblNewLabel_6_1_6_5_1.setBounds(148, 47, 96, 13);
		update_course.add(lblNewLabel_6_1_6_5_1);
		
		JLabel lblNewLabel_6_1_6_5_1_1 = new JLabel("New Course Info:");
		lblNewLabel_6_1_6_5_1_1.setBounds(402, 47, 109, 13);
		update_course.add(lblNewLabel_6_1_6_5_1_1);
		
		JPanel update_department = new JPanel();
		LayeredUpdatePane.add(update_department, "name_17843640523800");
		update_department.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_1 = new JLabel("Update a Department");
		lblNewLabel_6_6_5_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_1.setBounds(10, 10, 353, 23);
		update_department.add(lblNewLabel_6_6_5_1);
		
		JLabel lblNewLabel_6_1_6_5_1_2 = new JLabel("Old Department Info:");
		lblNewLabel_6_1_6_5_1_2.setBounds(148, 47, 134, 13);
		update_department.add(lblNewLabel_6_1_6_5_1_2);
		
		JLabel lblNewLabel_6_1_6_5_1_1_1 = new JLabel("New Department Info:");
		lblNewLabel_6_1_6_5_1_1_1.setBounds(377, 47, 134, 13);
		update_department.add(lblNewLabel_6_1_6_5_1_1_1);
		
		old_dept_id = new JTextField();
		old_dept_id.setColumns(10);
		old_dept_id.setBounds(98, 70, 215, 19);
		update_department.add(old_dept_id);
		
		old_dept_name = new JTextField();
		old_dept_name.setColumns(10);
		old_dept_name.setBounds(98, 95, 215, 19);
		update_department.add(old_dept_name);
		
		JButton delete_course_5_1 = new JButton("Update");
		delete_course_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_department();
			}
		});
		delete_course_5_1.setBounds(457, 124, 96, 21);
		update_department.add(delete_course_5_1);
		
		new_dept_name = new JTextField();
		new_dept_name.setColumns(10);
		new_dept_name.setBounds(338, 95, 215, 19);
		update_department.add(new_dept_name);
		
		new_dept_id = new JTextField();
		new_dept_id.setColumns(10);
		new_dept_id.setBounds(338, 70, 215, 19);
		update_department.add(new_dept_id);
		
		JLabel lblNewLabel_6_1_6_5_2 = new JLabel("Dept ID:");
		lblNewLabel_6_1_6_5_2.setBounds(10, 76, 109, 13);
		update_department.add(lblNewLabel_6_1_6_5_2);
		
		JLabel lblNewLabel_6_1_1_6_5_1 = new JLabel("Dept Name:");
		lblNewLabel_6_1_1_6_5_1.setBounds(10, 101, 109, 13);
		update_department.add(lblNewLabel_6_1_1_6_5_1);
		
		JPanel update_enrolled = new JPanel();
		LayeredUpdatePane.add(update_enrolled, "name_18493464652000");
		update_enrolled.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_2 = new JLabel("Update Enrollment");
		lblNewLabel_6_6_5_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_2.setBounds(10, 10, 353, 23);
		update_enrolled.add(lblNewLabel_6_6_5_2);
		
		JLabel lblNewLabel_6_1_6_5_3 = new JLabel("Student ID:");
		lblNewLabel_6_1_6_5_3.setBounds(10, 76, 78, 13);
		update_enrolled.add(lblNewLabel_6_1_6_5_3);
		
		JLabel lblNewLabel_6_1_1_6_5_2 = new JLabel("Course ID:");
		lblNewLabel_6_1_1_6_5_2.setBounds(10, 101, 109, 13);
		update_enrolled.add(lblNewLabel_6_1_1_6_5_2);
		
		JLabel lblNewLabel_6_1_1_1_5_5_1 = new JLabel("Exam One:");
		lblNewLabel_6_1_1_1_5_5_1.setBounds(10, 124, 109, 13);
		update_enrolled.add(lblNewLabel_6_1_1_1_5_5_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_3_1 = new JLabel("Final Exam:");
		lblNewLabel_6_1_1_1_1_1_4_3_1.setBounds(10, 170, 109, 13);
		update_enrolled.add(lblNewLabel_6_1_1_1_1_1_4_3_1);
		
		JLabel lblNewLabel_6_1_1_1_1_4_3_1 = new JLabel("Exam Two:");
		lblNewLabel_6_1_1_1_1_4_3_1.setBounds(10, 147, 78, 13);
		update_enrolled.add(lblNewLabel_6_1_1_1_1_4_3_1);
		
		old_final_exam = new JTextField();
		old_final_exam.setColumns(10);
		old_final_exam.setBounds(98, 164, 215, 19);
		update_enrolled.add(old_final_exam);
		
		old_exam_two = new JTextField();
		old_exam_two.setColumns(10);
		old_exam_two.setBounds(98, 141, 215, 19);
		update_enrolled.add(old_exam_two);
		
		old_exam_one = new JTextField();
		old_exam_one.setColumns(10);
		old_exam_one.setBounds(98, 118, 215, 19);
		update_enrolled.add(old_exam_one);
		
		old_course_ID = new JTextField();
		old_course_ID.setColumns(10);
		old_course_ID.setBounds(98, 95, 215, 19);
		update_enrolled.add(old_course_ID);
		
		old_student_id = new JTextField();
		old_student_id.setColumns(10);
		old_student_id.setBounds(98, 70, 215, 19);
		update_enrolled.add(old_student_id);
		
		JLabel lblNewLabel_6_1_6_5_1_3 = new JLabel("Old Enrollment Info:");
		lblNewLabel_6_1_6_5_1_3.setBounds(148, 47, 124, 13);
		update_enrolled.add(lblNewLabel_6_1_6_5_1_3);
		
		JLabel lblNewLabel_6_1_6_5_1_1_2 = new JLabel("New Enrollment Info:");
		lblNewLabel_6_1_6_5_1_1_2.setBounds(383, 47, 142, 13);
		update_enrolled.add(lblNewLabel_6_1_6_5_1_1_2);
		
		new_student_id = new JTextField();
		new_student_id.setColumns(10);
		new_student_id.setBounds(338, 70, 215, 19);
		update_enrolled.add(new_student_id);
		
		new_course_ID = new JTextField();
		new_course_ID.setColumns(10);
		new_course_ID.setBounds(338, 95, 215, 19);
		update_enrolled.add(new_course_ID);
		
		new_exam_one = new JTextField();
		new_exam_one.setColumns(10);
		new_exam_one.setBounds(338, 118, 215, 19);
		update_enrolled.add(new_exam_one);
		
		new_exam_two = new JTextField();
		new_exam_two.setColumns(10);
		new_exam_two.setBounds(338, 141, 215, 19);
		update_enrolled.add(new_exam_two);
		
		new_final_exam = new JTextField();
		new_final_exam.setColumns(10);
		new_final_exam.setBounds(338, 164, 215, 19);
		update_enrolled.add(new_final_exam);
		
		JButton delete_course_5_2 = new JButton("Update");
		delete_course_5_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_enrolled();
			}
		});
		delete_course_5_2.setBounds(457, 193, 96, 21);
		update_enrolled.add(delete_course_5_2);
		
		JPanel update_faculty = new JPanel();
		LayeredUpdatePane.add(update_faculty, "name_18500264840600");
		update_faculty.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_3_1 = new JLabel("Update Faculty:");
		lblNewLabel_6_6_5_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_3_1.setBounds(10, 10, 353, 23);
		update_faculty.add(lblNewLabel_6_6_5_3_1);
		
		JLabel lblNewLabel_6_1_6_5_1_4_1 = new JLabel("Old Faculty Info:");
		lblNewLabel_6_1_6_5_1_4_1.setBounds(148, 47, 96, 13);
		update_faculty.add(lblNewLabel_6_1_6_5_1_4_1);
		
		JLabel lblNewLabel_6_1_6_5_1_1_3_1 = new JLabel("New Faculty Info:");
		lblNewLabel_6_1_6_5_1_1_3_1.setBounds(402, 47, 109, 13);
		update_faculty.add(lblNewLabel_6_1_6_5_1_1_3_1);
		
		new_faculty_ID = new JTextField();
		new_faculty_ID.setColumns(10);
		new_faculty_ID.setBounds(338, 70, 215, 19);
		update_faculty.add(new_faculty_ID);
		
		new_faculty_name = new JTextField();
		new_faculty_name.setColumns(10);
		new_faculty_name.setBounds(338, 95, 215, 19);
		update_faculty.add(new_faculty_name);
		
		new_department_id = new JTextField();
		new_department_id.setColumns(10);
		new_department_id.setBounds(338, 118, 215, 19);
		update_faculty.add(new_department_id);
		
		JButton delete_course_5_3_1 = new JButton("Update");
		delete_course_5_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_faculty();
			}
		});
		delete_course_5_3_1.setBounds(457, 147, 96, 21);
		update_faculty.add(delete_course_5_3_1);
		
		old_department_id = new JTextField();
		old_department_id.setColumns(10);
		old_department_id.setBounds(98, 118, 215, 19);
		update_faculty.add(old_department_id);
		
		old_faculty_name = new JTextField();
		old_faculty_name.setColumns(10);
		old_faculty_name.setBounds(98, 95, 215, 19);
		update_faculty.add(old_faculty_name);
		
		old_faculty_ID = new JTextField();
		old_faculty_ID.setColumns(10);
		old_faculty_ID.setBounds(98, 70, 215, 19);
		update_faculty.add(old_faculty_ID);
		
		JLabel lblNewLabel_6_1_6_5_4_1 = new JLabel("Faculty ID:");
		lblNewLabel_6_1_6_5_4_1.setBounds(10, 76, 78, 13);
		update_faculty.add(lblNewLabel_6_1_6_5_4_1);
		
		JLabel lblNewLabel_6_1_1_6_5_3_1 = new JLabel("Faculty Name:");
		lblNewLabel_6_1_1_6_5_3_1.setBounds(10, 101, 109, 13);
		update_faculty.add(lblNewLabel_6_1_1_6_5_3_1);
		
		JLabel lblNewLabel_6_1_1_1_5_5_2_1 = new JLabel("Dept ID:");
		lblNewLabel_6_1_1_1_5_5_2_1.setBounds(10, 124, 109, 13);
		update_faculty.add(lblNewLabel_6_1_1_1_5_5_2_1);
		
		JPanel update_staff = new JPanel();
		LayeredUpdatePane.add(update_staff, "name_18502792286100");
		update_staff.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_3 = new JLabel("Update Staff:");
		lblNewLabel_6_6_5_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_3.setBounds(10, 10, 353, 23);
		update_staff.add(lblNewLabel_6_6_5_3);
		
		JLabel lblNewLabel_6_1_6_5_1_4 = new JLabel("Old Staff Info:");
		lblNewLabel_6_1_6_5_1_4.setBounds(148, 47, 96, 13);
		update_staff.add(lblNewLabel_6_1_6_5_1_4);
		
		JLabel lblNewLabel_6_1_6_5_1_1_3 = new JLabel("New Staff Info:");
		lblNewLabel_6_1_6_5_1_1_3.setBounds(402, 47, 109, 13);
		update_staff.add(lblNewLabel_6_1_6_5_1_1_3);
		
		new_staff_id = new JTextField();
		new_staff_id.setColumns(10);
		new_staff_id.setBounds(338, 70, 215, 19);
		update_staff.add(new_staff_id);
		
		new_staff_name = new JTextField();
		new_staff_name.setColumns(10);
		new_staff_name.setBounds(338, 95, 215, 19);
		update_staff.add(new_staff_name);
		
		new_dept_ID = new JTextField();
		new_dept_ID.setColumns(10);
		new_dept_ID.setBounds(338, 118, 215, 19);
		update_staff.add(new_dept_ID);
		
		JButton delete_course_5_3 = new JButton("Update");
		delete_course_5_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_staff();
			}
		});
		delete_course_5_3.setBounds(457, 147, 96, 21);
		update_staff.add(delete_course_5_3);
		
		old_dept_ID = new JTextField();
		old_dept_ID.setColumns(10);
		old_dept_ID.setBounds(98, 118, 215, 19);
		update_staff.add(old_dept_ID);
		
		old_staff_name = new JTextField();
		old_staff_name.setColumns(10);
		old_staff_name.setBounds(98, 95, 215, 19);
		update_staff.add(old_staff_name);
		
		old_staff_id = new JTextField();
		old_staff_id.setColumns(10);
		old_staff_id.setBounds(98, 70, 215, 19);
		update_staff.add(old_staff_id);
		
		JLabel lblNewLabel_6_1_6_5_4 = new JLabel("Staff ID:");
		lblNewLabel_6_1_6_5_4.setBounds(10, 76, 78, 13);
		update_staff.add(lblNewLabel_6_1_6_5_4);
		
		JLabel lblNewLabel_6_1_1_6_5_3 = new JLabel("Staff Name:");
		lblNewLabel_6_1_1_6_5_3.setBounds(10, 101, 109, 13);
		update_staff.add(lblNewLabel_6_1_1_6_5_3);
		
		JLabel lblNewLabel_6_1_1_1_5_5_2 = new JLabel("Dept ID:");
		lblNewLabel_6_1_1_1_5_5_2.setBounds(10, 124, 109, 13);
		update_staff.add(lblNewLabel_6_1_1_1_5_5_2);
		
		JPanel update_students = new JPanel();
		LayeredUpdatePane.add(update_students, "name_18508147555200");
		update_students.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_4 = new JLabel("Update a Student:");
		lblNewLabel_6_6_5_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4.setBounds(10, 10, 353, 23);
		update_students.add(lblNewLabel_6_6_5_4);
		
		JLabel lblNewLabel_6_1_6_5_1_5 = new JLabel("Old Student Info:");
		lblNewLabel_6_1_6_5_1_5.setBounds(148, 47, 96, 13);
		update_students.add(lblNewLabel_6_1_6_5_1_5);
		
		JLabel lblNewLabel_6_1_6_5_1_1_4 = new JLabel("New Student Info:");
		lblNewLabel_6_1_6_5_1_1_4.setBounds(402, 47, 109, 13);
		update_students.add(lblNewLabel_6_1_6_5_1_1_4);
		
		new_student_ID = new JTextField();
		new_student_ID.setColumns(10);
		new_student_ID.setBounds(338, 70, 215, 19);
		update_students.add(new_student_ID);
		
		new_student_name = new JTextField();
		new_student_name.setColumns(10);
		new_student_name.setBounds(338, 95, 215, 19);
		update_students.add(new_student_name);
		
		new_major = new JTextField();
		new_major.setColumns(10);
		new_major.setBounds(338, 118, 215, 19);
		update_students.add(new_major);
		
		new_student_year = new JTextField();
		new_student_year.setColumns(10);
		new_student_year.setBounds(338, 141, 215, 19);
		update_students.add(new_student_year);
		
		new_age = new JTextField();
		new_age.setColumns(10);
		new_age.setBounds(338, 164, 215, 19);
		update_students.add(new_age);
		
		JButton delete_course_5_4 = new JButton("Update");
		delete_course_5_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_students();
			}
		});
		delete_course_5_4.setBounds(457, 193, 96, 21);
		update_students.add(delete_course_5_4);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_3_2 = new JLabel("Age:");
		lblNewLabel_6_1_1_1_1_1_4_3_2.setBounds(10, 170, 109, 13);
		update_students.add(lblNewLabel_6_1_1_1_1_1_4_3_2);
		
		JLabel lblNewLabel_6_1_1_1_1_4_3_2 = new JLabel("Student Year:");
		lblNewLabel_6_1_1_1_1_4_3_2.setBounds(10, 147, 78, 13);
		update_students.add(lblNewLabel_6_1_1_1_1_4_3_2);
		
		JLabel lblNewLabel_6_1_1_1_5_5_3 = new JLabel("Major:");
		lblNewLabel_6_1_1_1_5_5_3.setBounds(10, 124, 109, 13);
		update_students.add(lblNewLabel_6_1_1_1_5_5_3);
		
		JLabel lblNewLabel_6_1_1_6_5_4 = new JLabel("Student Name:");
		lblNewLabel_6_1_1_6_5_4.setBounds(10, 101, 109, 13);
		update_students.add(lblNewLabel_6_1_1_6_5_4);
		
		JLabel lblNewLabel_6_1_6_5_5 = new JLabel("Student ID:");
		lblNewLabel_6_1_6_5_5.setBounds(10, 76, 78, 13);
		update_students.add(lblNewLabel_6_1_6_5_5);
		
		old_student_ID = new JTextField();
		old_student_ID.setColumns(10);
		old_student_ID.setBounds(98, 70, 215, 19);
		update_students.add(old_student_ID);
		
		old_student_name = new JTextField();
		old_student_name.setColumns(10);
		old_student_name.setBounds(98, 95, 215, 19);
		update_students.add(old_student_name);
		
		old_major = new JTextField();
		old_major.setColumns(10);
		old_major.setBounds(98, 118, 215, 19);
		update_students.add(old_major);
		
		old_student_year = new JTextField();
		old_student_year.setColumns(10);
		old_student_year.setBounds(98, 141, 215, 19);
		update_students.add(old_student_year);
		
		old_age = new JTextField();
		old_age.setColumns(10);
		old_age.setBounds(98, 164, 215, 19);
		update_students.add(old_age);
		
		JPanel panel_search = new JPanel();
		layeredStaffPane.add(panel_search, "name_54550825562900");
		panel_search.setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Search Database:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(10, 10, 162, 21);
		panel_search.add(lblNewLabel_1_1);
		
		JLayeredPane layeredSearchPane = new JLayeredPane();
		layeredSearchPane.setBounds(157, 10, 565, 370);
		panel_search.add(layeredSearchPane);
		layeredSearchPane.setLayout(new CardLayout(0, 0));
		
		JButton btnSearchCourses = new JButton("Courses");
		btnSearchCourses.setBounds(10, 42, 137, 21);
		panel_search.add(btnSearchCourses);
		
		JButton btnSearchDepartment = new JButton("Department");
		btnSearchDepartment.setBounds(10, 73, 137, 21);
		panel_search.add(btnSearchDepartment);
		
		JButton btnSearchEnrolled = new JButton("Enrolled");
		btnSearchEnrolled.setBounds(10, 104, 137, 21);
		panel_search.add(btnSearchEnrolled);
		
		JButton btnSearchFaculty = new JButton("Faculty");
		btnSearchFaculty.setBounds(10, 135, 137, 21);
		panel_search.add(btnSearchFaculty);
		
		JButton btnSerachStaff = new JButton("Staff");
		btnSerachStaff.setBounds(10, 166, 137, 21);
		panel_search.add(btnSerachStaff);
		
		JButton btnSearchStudents = new JButton("Students");
		btnSearchStudents.setBounds(10, 197, 137, 21);
		panel_search.add(btnSearchStudents);
		
		
		///Update
		//Update Courses
			JButton btnSearchCourses_1 = new JButton("Courses");
			btnSearchCourses_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					switchUpdatePanels(update_course);
				}
			});
			btnSearchCourses_1.setBounds(10, 42, 137, 21);
			panel_update.add(btnSearchCourses_1);
		
		
		//Update Department Button
				JButton btnSearchDepartment_1 = new JButton("Department");
				btnSearchDepartment_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchUpdatePanels(update_department);
					}
				});
				
				btnSearchDepartment_1.setBounds(10, 73, 137, 21);
				panel_update.add(btnSearchDepartment_1);
				
		//Update Enrollment Button
				JButton btnSearchEnrolled_1 = new JButton("Enrolled");
				btnSearchEnrolled_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchUpdatePanels(update_enrolled);
					}
				});
				btnSearchEnrolled_1.setBounds(10, 104, 137, 21);
				panel_update.add(btnSearchEnrolled_1);
				
		//Update Faculty Button
				JButton btnSearchFaculty_1 = new JButton("Faculty");
				btnSearchFaculty_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchUpdatePanels(update_faculty);
					}
				});
				btnSearchFaculty_1.setBounds(10, 135, 137, 21);
				panel_update.add(btnSearchFaculty_1);
		
		//Update Staff 
				JButton btnSerachStaff_1 = new JButton("Staff");
				btnSerachStaff_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchUpdatePanels(update_staff);
					}
				});
				btnSerachStaff_1.setBounds(10, 166, 137, 21);
				panel_update.add(btnSerachStaff_1);
		
		//Update Students
				JButton btnSearchStudents_1 = new JButton("Students");
				btnSearchStudents_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchUpdatePanels(update_students);
					}
				});
				btnSearchStudents_1.setBounds(10, 197, 137, 21);
				panel_update.add(btnSearchStudents_1);
				
				
				
				
		
		///Delete 
		//Delete Courses Button
				JButton btnAddCourses_1 = new JButton("Courses");
				btnAddCourses_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_courses);
					}
				});
				btnAddCourses_1.setBounds(10, 42, 137, 21);
				panel_delete.add(btnAddCourses_1);
		
		//Delete Department Button
				JButton btnAddDepartment_1 = new JButton("Department");
				btnAddDepartment_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_department);
					}
				});
				btnAddDepartment_1.setBounds(10, 73, 137, 21);
				panel_delete.add(btnAddDepartment_1);
		
		//Delete Enrolled 
				JButton btnEnrolled_1 = new JButton("Enrolled");
				btnEnrolled_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_enrolled);
					}
				});
				btnEnrolled_1.setBounds(10, 104, 137, 21);
				panel_delete.add(btnEnrolled_1);
		
		//Delete Faculty
				JButton btnFaculty_1 = new JButton("Faculty");
				btnFaculty_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_faculty);
					}
				});
				btnFaculty_1.setBounds(10, 135, 137, 21);
				panel_delete.add(btnFaculty_1);		
	
				//Remove Button?
				JButton delete_course_2 = new JButton("Remove");
				delete_course_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						delete_faculty();
					}
				});
				delete_course_2.setBounds(138, 120, 96, 21);
				panel_delete_faculty.add(delete_course_2);
				
		//Delete Staff
				JButton btnStaff_1 = new JButton("Staff");
				btnStaff_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_staff);
					}
				});
				btnStaff_1.setBounds(10, 166, 137, 21);
				panel_delete.add(btnStaff_1);
		
		
		//Delete Students
				JButton btnStudents_1 = new JButton("Students");
				btnStudents_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchDeletePanels(panel_delete_students);
					}
				});
				btnStudents_1.setBounds(10, 197, 137, 21);
				panel_delete.add(btnStudents_1);
				
		
		//Main Menu
		
		JPanel StaffOptions = new JPanel();
		StaffOptions.setBounds(10, 106, 110, 400);
		getContentPane().add(StaffOptions);
		StaffOptions.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("Edit Records");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(10, 21, 90, 17);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		StaffOptions.add(lblNewLabel_5);
		
		JButton btnNewButton_Search = new JButton("Search");
		btnNewButton_Search.setBounds(10, 53, 90, 41);
		StaffOptions.add(btnNewButton_Search);
		
		JButton btnNewButton_Update = new JButton("Update");
		btnNewButton_Update.setBounds(10, 119, 90, 41);
		StaffOptions.add(btnNewButton_Update);
		
		JButton btnNewButton_Delete = new JButton("Delete");
		btnNewButton_Delete.setBounds(10, 182, 90, 41);
		StaffOptions.add(btnNewButton_Delete);
		
		JButton btnNewButton_Add = new JButton("Add");
		btnNewButton_Add.setBounds(10, 247, 90, 41);
		StaffOptions.add(btnNewButton_Add);
		
		JButton btnNewButton_Add_1 = new JButton("Log out");
		btnNewButton_Add_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_Add_1.setBounds(10, 312, 90, 78);
		StaffOptions.add(btnNewButton_Add_1);
		
		btnNewButton_Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(panel_add);
			}
		});
		btnNewButton_Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(panel_delete);
			}
		});
		btnNewButton_Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(panel_update);
				
			}
		});
		btnNewButton_Search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				staff_search_home stframe = new staff_search_home();
				stframe.setVisible(true);			
				dispose();
			}
		});
	
	}
}
