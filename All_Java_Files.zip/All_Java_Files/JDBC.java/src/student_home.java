import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;








public class student_home extends JFrame {

	private JPanel contentPane;
	private JLayeredPane layeredPane;
	private JTable student_info_table;
	private static JTextField old_age;
	private static JTextField old_student_level;
	private static JTextField old_major;
	private static JTextField old_student_name;
	private static JTextField old_student_id;
	private static JTextField new_student_id;
	private static JTextField new_student_name;
	private static JTextField new_major;
	private static JTextField new_student_level;
	private static JTextField new_age;
	private JTable enrolled_courses;
	private JTextField txt_course_name;
	private JTextField txt_course_id;
	private JTextField txt_time;
	private JTextField txt_faculty_name;
	private JTable enroll_table;
	private static JTextField enroll_cid;
	private static JTextField drop_cid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					student_home frame = new student_home(100001);
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	/**
	 * Create the frame.
	 */

	public void switchPanels(JPanel panel) {
		layeredPane.removeAll();
		layeredPane.add(panel);
		layeredPane.repaint();
		layeredPane.revalidate();
	}
	
	
	//Create Student Info Page
	public void create_student_info_table(int student_id) {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			String query = "SELECT * FROM students WHERE sid = ?";
			PreparedStatement pst = con.prepareStatement(query);
				
			pst.setInt(1, student_id); 
			ResultSet rs = pst.executeQuery();
			student_info_table.setModel(DbUtils.resultSetToTableModel(rs));
				
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	//Update Students
	static void update_student(int student_id) {
		try {
			
			if (student_id == Integer.parseInt(old_student_id.getText()))
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
					
			String query = "UPDATE students "
					+ " SET sid = ?, sname = ?, major = ?, s_level = ?, age = ? "
					+ " WHERE sid = ? AND sname = ? AND major = ? AND s_level = ? AND age = ? "; 

			PreparedStatement pst = con.prepareStatement(query);	
			
			//New
			pst.setInt(1, student_id);
			pst.setString(2, new_student_name.getText());
			pst.setString(3, new_major.getText());
			pst.setString(4, new_student_level.getText());
			pst.setInt(5, Integer.parseInt(new_age.getText()));
			
			//Old
			pst.setInt(6, Integer.parseInt(old_student_id.getText()));
			pst.setString(7, old_student_name.getText());
			pst.setString(8, old_major.getText());
			pst.setString(9, old_student_level.getText());
			pst.setInt(10, Integer.parseInt(old_age.getText()));


			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(null, "The Student Database has been updated!");	
			
			return;
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "The Student Database failed to update.");
			return;
		}
	}
	
	
	
	
	
	
	//Create Student Enrollment Page
		public void create_enrolled_table(int student_id) {
			try {
				
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				String query = "SELECT * FROM enrolled WHERE sid = ?";
				PreparedStatement pst = con.prepareStatement(query);
					
				pst.setInt(1, student_id); 
				ResultSet rs = pst.executeQuery();
				enrolled_courses.setModel(DbUtils.resultSetToTableModel(rs));
					
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
	
		
		
		//Enrollment Search Table
		
		//Initialize Course Table
		public void create_enroll_table() {
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				
					String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid";
					PreparedStatement pst = con.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
					
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
		
		
	
		//Search by course name!
		public void search_course_name() {
			try {
				
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				if (txt_course_name.getText().equals("")) {
					String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid";
					PreparedStatement pst = con.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
				} else 
				{
					String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid AND C.cname = ?";
					PreparedStatement pst = con.prepareStatement(query);
					
					pst.setString(1, txt_course_name.getText()); 
					ResultSet rs = pst.executeQuery();
					enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
		
		
		//Search by course id!
				public void search_course_id() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (txt_course_id.getText().equals("")) {
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid AND C.cid = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, txt_course_id.getText()); 
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
		
		//Search by course time!
				public void search_course_time() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (txt_time.getText().equals("")) {
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid AND C.meets_at = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, txt_time.getText()); 
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
		
				
		//Search by course id!
				public void search_course_faculty() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (txt_faculty_name.getText().equals("")) {
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT C.cid, C.cname, C.meets_at, C.room, F.fname, C.slimit FROM courses C, faculty F WHERE C.fid = F.fid AND F.fname = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, txt_faculty_name.getText()); 
							ResultSet rs = pst.executeQuery();
							enroll_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}		
		
		
		//Enroll in a Class
		static void enroll_student(int student_id) {
			
			//SQL Initialization 
				
			try {
				
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
					
				
				
				// CHECK FOR CLASS LIMIT
				
					String check = "SELECT COUNT(cid) AS students_enrolled FROM enrolled WHERE cid = ?";
					PreparedStatement cpst = con.prepareStatement(check);
					cpst.setString(1, enroll_cid.getText());
					ResultSet rs = cpst.executeQuery();
					
					rs.next();
					int count = rs.getInt("students_enrolled");
					rs.close();
				
						
				

					String limit = "SELECT slimit AS enrollment_cap FROM courses WHERE cid = ?";
					PreparedStatement lpst = con.prepareStatement(limit);
					lpst.setString(1, enroll_cid.getText());
					

					
					ResultSet rps = lpst.executeQuery();
					
					
					
					rps.next();
					int limit_count = rps.getInt("enrollment_cap");
					rps.close();
				
				if (limit_count > count) {
					
					String query = "INSERT INTO enrolled (sid, cid) values (?,?)";
					PreparedStatement pst = con.prepareStatement(query);	
			
					pst.setInt(1,student_id);
					pst.setString(2, enroll_cid.getText());
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "The Enrollment Database has been updated!");	
					return;
					
				}else{
					JOptionPane.showMessageDialog(null, "Saddly this class is already full.");
					return;
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Enrollment Database failed to update.");
				return;
			}
			
				
			
		}

		
		//Drop a Class
		//Delete Enrolled.
		static void drop_class(int student_id){
			
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
				String query = "DELETE FROM enrolled WHERE sid = ? AND cid = ?"; 
				PreparedStatement pst = con.prepareStatement(query);	
				
				pst.setInt(1,student_id);
				pst.setString(2, drop_cid.getText());
				
				pst.executeUpdate();
				
				JOptionPane.showMessageDialog(null, "The Enrolled Database has been updated!");	
				return;
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "The Enrolled Database failed to update.");
				return;
			}
			
		}
		
		
		
		
		
	public student_home(int student_id) {
		setResizable(false);
		
		getContentPane().setForeground(new Color(0, 0, 0));
		setBackground(new Color(192, 192, 192));
		getContentPane().setBackground(new Color(192, 192, 192));
		getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		setBounds(100, 100, 890, 597);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JPanel Database_Selection = new JPanel();
		Database_Selection.setLayout(null);
		Database_Selection.setBounds(10, 77, 139, 473);
		getContentPane().add(Database_Selection);
		
		JLabel lblNewLabel_5 = new JLabel("Student Tab:");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 21, 119, 42);
		Database_Selection.add(lblNewLabel_5);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnLogOut.setBounds(10, 394, 119, 69);
		Database_Selection.add(btnLogOut);
		

		
		
		JPanel header = new JPanel();
		header.setBounds(0, 0, 876, 67);
		getContentPane().add(header);
		
		JLabel lblNewLabel = new JLabel("Student Home");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 50));
		lblNewLabel.setBackground(new Color(128, 0, 0));
		header.add(lblNewLabel);
		
		layeredPane = new JLayeredPane();
		layeredPane.setBounds(159, 77, 707, 473);
		getContentPane().add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		
		JPanel student_info_panel = new JPanel();
		layeredPane.add(student_info_panel, "name_175165483274200");
		student_info_panel.setLayout(null);
		
		JPanel course_panel = new JPanel();
		layeredPane.add(course_panel, "name_175150132639300");
		course_panel.setLayout(null);
		
		JLabel lblNewLabel_6_6_5_4_2 = new JLabel("Your Enrolled Courses:");
		lblNewLabel_6_6_5_4_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4_2.setBounds(10, 10, 418, 23);
		course_panel.add(lblNewLabel_6_6_5_4_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(20, 43, 677, 420);
		course_panel.add(scrollPane_1);
		
		enrolled_courses = new JTable();
		enrolled_courses.setEnabled(false);
		enrolled_courses.setRowSelectionAllowed(false);
		scrollPane_1.setViewportView(enrolled_courses);
		create_enrolled_table(student_id);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 97, 687, 46);
		student_info_panel.add(scrollPane);
		
		
		//Create Student Info Table
		student_info_table = new JTable();
		student_info_table.setRowSelectionAllowed(false);
		student_info_table.setEnabled(false);
		scrollPane.setViewportView(student_info_table);
		
		JLabel lblNewLabel_6_1_6_5_5 = new JLabel("Student ID:");
		lblNewLabel_6_1_6_5_5.setBounds(10, 234, 78, 13);
		student_info_panel.add(lblNewLabel_6_1_6_5_5);
		
		JLabel lblNewLabel_6_1_1_6_5_4 = new JLabel("Student Name:");
		lblNewLabel_6_1_1_6_5_4.setBounds(10, 259, 109, 13);
		student_info_panel.add(lblNewLabel_6_1_1_6_5_4);
		
		JLabel lblNewLabel_6_1_1_1_5_5_3 = new JLabel("Major:");
		lblNewLabel_6_1_1_1_5_5_3.setBounds(10, 282, 109, 13);
		student_info_panel.add(lblNewLabel_6_1_1_1_5_5_3);
		
		JLabel lblNewLabel_6_1_1_1_1_4_3_2 = new JLabel("Student Year:");
		lblNewLabel_6_1_1_1_1_4_3_2.setBounds(10, 305, 78, 13);
		student_info_panel.add(lblNewLabel_6_1_1_1_1_4_3_2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_4_3_2 = new JLabel("Age:");
		lblNewLabel_6_1_1_1_1_1_4_3_2.setBounds(10, 328, 109, 13);
		student_info_panel.add(lblNewLabel_6_1_1_1_1_1_4_3_2);
		
		old_age = new JTextField();
		old_age.setColumns(10);
		old_age.setBounds(98, 322, 215, 19);
		student_info_panel.add(old_age);
		
		old_student_level = new JTextField();
		old_student_level.setColumns(10);
		old_student_level.setBounds(98, 299, 215, 19);
		student_info_panel.add(old_student_level);
		
		old_major = new JTextField();
		old_major.setColumns(10);
		old_major.setBounds(98, 276, 215, 19);
		student_info_panel.add(old_major);
		
		old_student_name = new JTextField();
		old_student_name.setColumns(10);
		old_student_name.setBounds(98, 253, 215, 19);
		student_info_panel.add(old_student_name);
		
		old_student_id = new JTextField();
		old_student_id.setColumns(10);
		old_student_id.setBounds(98, 228, 215, 19);
		student_info_panel.add(old_student_id);
		
		JLabel lblNewLabel_6_1_6_5_1_5 = new JLabel("Current Information:");
		lblNewLabel_6_1_6_5_1_5.setBounds(98, 205, 148, 13);
		student_info_panel.add(lblNewLabel_6_1_6_5_1_5);
		
		JLabel lblNewLabel_6_6_5_4 = new JLabel("Update your profile:");
		lblNewLabel_6_6_5_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4.setBounds(10, 168, 353, 23);
		student_info_panel.add(lblNewLabel_6_6_5_4);
		
		JLabel lblNewLabel_6_1_6_5_1_1_4 = new JLabel("New Information:");
		lblNewLabel_6_1_6_5_1_1_4.setBounds(338, 205, 109, 13);
		student_info_panel.add(lblNewLabel_6_1_6_5_1_1_4);
		
		new_student_id = new JTextField();
		new_student_id.setColumns(10);
		new_student_id.setBounds(338, 228, 215, 19);
		student_info_panel.add(new_student_id);
		
		new_student_name = new JTextField();
		new_student_name.setColumns(10);
		new_student_name.setBounds(338, 253, 215, 19);
		student_info_panel.add(new_student_name);
		
		new_major = new JTextField();
		new_major.setColumns(10);
		new_major.setBounds(338, 276, 215, 19);
		student_info_panel.add(new_major);
		
		new_student_level = new JTextField();
		new_student_level.setColumns(10);
		new_student_level.setBounds(338, 299, 215, 19);
		student_info_panel.add(new_student_level);
		
		new_age = new JTextField();
		new_age.setColumns(10);
		new_age.setBounds(338, 322, 215, 19);
		student_info_panel.add(new_age);
		
		JButton update_student_info = new JButton("Update");
		update_student_info.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update_student(student_id);
				create_student_info_table(student_id);
			}
		});
		update_student_info.setBounds(457, 351, 96, 21);
		student_info_panel.add(update_student_info);
		
		JLabel lblNewLabel_6_6_5_4_1 = new JLabel("Welcome back!");
		lblNewLabel_6_6_5_4_1.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel_6_6_5_4_1.setBounds(10, 27, 501, 58);
		student_info_panel.add(lblNewLabel_6_6_5_4_1);
		create_student_info_table(student_id);
		
		JPanel enroll_panel = new JPanel();
		layeredPane.add(enroll_panel, "name_175263202223000");
		enroll_panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Search by course name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 10, 168, 27);
		enroll_panel.add(lblNewLabel_1);
		
		txt_course_name = new JTextField();
		txt_course_name.setColumns(10);
		txt_course_name.setBounds(168, 16, 168, 19);
		enroll_panel.add(txt_course_name);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				search_course_name();
			}
		});
		btnNewButton.setBounds(346, 15, 85, 21);
		enroll_panel.add(btnNewButton);
		
		JLabel lblNewLabel_1_1 = new JLabel("Search by course ID:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(10, 40, 168, 27);
		enroll_panel.add(lblNewLabel_1_1);
		
		txt_course_id = new JTextField();
		txt_course_id.setColumns(10);
		txt_course_id.setBounds(168, 46, 168, 19);
		enroll_panel.add(txt_course_id);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				search_course_id();
			}
		});
		btnNewButton_1.setBounds(346, 45, 85, 21);
		enroll_panel.add(btnNewButton_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Search by time:");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1_1_1.setBounds(10, 69, 168, 27);
		enroll_panel.add(lblNewLabel_1_1_1);
		
		txt_time = new JTextField();
		txt_time.setColumns(10);
		txt_time.setBounds(168, 75, 168, 19);
		enroll_panel.add(txt_time);
		
		JButton btnNewButton_1_1 = new JButton("Search");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 search_course_time();
			}
		});
		btnNewButton_1_1.setBounds(346, 74, 85, 21);
		enroll_panel.add(btnNewButton_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Search by Faculty name:");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1_1_1_1.setBounds(10, 98, 168, 27);
		enroll_panel.add(lblNewLabel_1_1_1_1);
		
		txt_faculty_name = new JTextField();
		txt_faculty_name.setColumns(10);
		txt_faculty_name.setBounds(168, 104, 168, 19);
		enroll_panel.add(txt_faculty_name);
		
		JButton btnNewButton_1_1_1 = new JButton("Search");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 search_course_faculty();
			}
		});
		btnNewButton_1_1_1.setBounds(346, 103, 85, 21);
		enroll_panel.add(btnNewButton_1_1_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 135, 687, 180);
		enroll_panel.add(scrollPane_2);
		
		enroll_table = new JTable();
		scrollPane_2.setViewportView(enroll_table);
		create_enroll_table();
		
		JLabel lblNewLabel_6_6_5_4_3 = new JLabel("Search Classes:");
		lblNewLabel_6_6_5_4_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4_3.setBounds(441, 98, 215, 23);
		enroll_panel.add(lblNewLabel_6_6_5_4_3);
		
		JLabel lblNewLabel_6_6_5_4_3_1 = new JLabel("Enroll in a class:");
		lblNewLabel_6_6_5_4_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4_3_1.setBounds(10, 325, 215, 23);
		enroll_panel.add(lblNewLabel_6_6_5_4_3_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Course Cid:");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(10, 358, 101, 27);
		enroll_panel.add(lblNewLabel_1_2);
		
		enroll_cid = new JTextField();
		enroll_cid.setColumns(10);
		enroll_cid.setBounds(117, 359, 168, 19);
		enroll_panel.add(enroll_cid);
		
		JButton btnNewButton_1_1_2 = new JButton("Enroll");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enroll_student(student_id);
			}
		});
		btnNewButton_1_1_2.setBounds(199, 388, 85, 21);
		enroll_panel.add(btnNewButton_1_1_2);
		
		JButton btnNewButton_1_1_2_1 = new JButton("Drop");
		btnNewButton_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drop_class(student_id);
			}
		});
		btnNewButton_1_1_2_1.setBounds(611, 388, 85, 21);
		enroll_panel.add(btnNewButton_1_1_2_1);
		
		JLabel lblNewLabel_6_6_5_4_3_1_1 = new JLabel("Drop a class:");
		lblNewLabel_6_6_5_4_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_6_6_5_4_3_1_1.setBounds(422, 325, 215, 23);
		enroll_panel.add(lblNewLabel_6_6_5_4_3_1_1);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Course Cid:");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1_2_1.setBounds(422, 358, 101, 27);
		enroll_panel.add(lblNewLabel_1_2_1);
		
		drop_cid = new JTextField();
		drop_cid.setColumns(10);
		drop_cid.setBounds(529, 359, 168, 19);
		enroll_panel.add(drop_cid);
		

		//Panel Buttons
		JButton btnCoursses = new JButton("Your Courses");
		btnCoursses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(course_panel);
				create_enrolled_table(student_id);
				
			}
		});
		btnCoursses.setBounds(10, 60, 119, 69);
		Database_Selection.add(btnCoursses);
		
		
		JButton btnEnroll = new JButton("Enroll");
		btnEnroll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(enroll_panel);
			}
		});
		btnEnroll.setBounds(10, 172, 119, 69);
		Database_Selection.add(btnEnroll);
		
		
		JButton btnStudentId = new JButton("Student Info:");
		btnStudentId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switchPanels(student_info_panel);
			}
		});
		btnStudentId.setBounds(10, 283, 119, 69);
		Database_Selection.add(btnStudentId);
		
		
	}
}
