import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import javax.swing.JTable;
import java.sql.*;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;



public class staff_search_home extends JFrame {

	private JPanel contentPane;
	private JTable courses_table;
	private static JTextField txt_course_name;
	private static JTextField txt_course_id;
	private static JTextField txt_course_time;
	private static JTextField txt_course_faculty;
	
	private JLayeredPane layeredSearchPane;
	private JTextField search_department_id;
	private JTextField search_department_name;
	private JTable department_table;
	private JTextField search_student_ID;
	private JTextField search_course_ID;
	private JTable enrolled_table;
	private JTextField search_faculty_name;
	private JTextField search_department_ID;
	private JTable faculty_table;
	private JTextField search_staff_name;
	private JTable staff_table;
	private JTextField search_student_year;
	private JTextField search_student_major;
	private JTextField search_student_name;
	private JTable student_table;
	
	
	
	public void switchPanels(JPanel panel) {
		layeredSearchPane.removeAll();
		layeredSearchPane.add(panel);
		layeredSearchPane.repaint();
		layeredSearchPane.revalidate();
	}
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					staff_search_home frame = new staff_search_home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	//Initialize Course Table
	public void create_course_table() {
		try {
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			
				String query = "SELECT * FROM courses";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
				
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//Initialize Department Table
	public void create_department_table() {
		try {
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			
				String query = "SELECT * FROM department";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				department_table.setModel(DbUtils.resultSetToTableModel(rs));
				
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	//Enrolled Table
		public void create_enrolled_table() {
			try {
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				
					String query = "SELECT * FROM enrolled";
					PreparedStatement pst = con.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					enrolled_table.setModel(DbUtils.resultSetToTableModel(rs));
					
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
		
	
		
		//Faculty Table
				public void create_faculty_table() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						
							String query = "SELECT * FROM faculty";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							faculty_table.setModel(DbUtils.resultSetToTableModel(rs));
							
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
		
				
		//Staff Table
				public void create_staff_table() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						
							String query = "SELECT * FROM staff";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							staff_table.setModel(DbUtils.resultSetToTableModel(rs));
							
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
		
		//Students Table
				public void create_students_table() {
					try {
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						
							String query = "SELECT * FROM students";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
							
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}		
				
				
				
				
				
				
				
	
	//Search THROUGH COURSES!!
	public void search_course_name() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (txt_course_name.getText().equals("")) {
				String query = "SELECT * FROM courses";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM courses WHERE cname = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, txt_course_name.getText()); 
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	public void search_course_id() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (txt_course_id.getText().equals("")) {
				String query = "SELECT * FROM courses";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM courses WHERE cid = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, txt_course_id.getText()); 
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void search_course_faculty() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (txt_course_faculty.getText().equals("")) {
				String query = "SELECT * FROM courses";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM courses WHERE fid = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, txt_course_faculty.getText()); 
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void search_course_time() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (txt_course_time.getText().equals("")) {
				String query = "SELECT * FROM courses";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM courses WHERE meets_at = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, txt_course_time.getText()); 
				ResultSet rs = pst.executeQuery();
				courses_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	
	
	
	//Search THROUGH DEPARTMENTS!
	public void search_department_id() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (search_department_id.getText().equals("")) {
				String query = "SELECT * FROM department";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				department_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM department WHERE did = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, search_department_id.getText()); 
				ResultSet rs = pst.executeQuery();
				department_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void search_department_name() {
		try {
			
			//SQL Initialization 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
			
			if (search_department_name.getText().equals("")) {
				String query = "SELECT * FROM department";
				PreparedStatement pst = con.prepareStatement(query);
				ResultSet rs = pst.executeQuery();
				department_table.setModel(DbUtils.resultSetToTableModel(rs));
			} else 
			{
				String query = "SELECT * FROM department WHERE dname = ?";
				PreparedStatement pst = con.prepareStatement(query);
				
				pst.setString(1, search_department_name.getText()); 
				ResultSet rs = pst.executeQuery();
				department_table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	
	
	//Search THROUGH ENROLLMENT!
		public void search_enrolled_sid() {
			try {
				
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				if (search_student_ID.getText().equals("")) {
					String query = "SELECT * FROM enrolled";
					PreparedStatement pst = con.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					enrolled_table.setModel(DbUtils.resultSetToTableModel(rs));
				} else 
				{
					String query = "SELECT * FROM enrolled WHERE sid = ?";
					PreparedStatement pst = con.prepareStatement(query);
					
					pst.setString(1, search_student_ID.getText()); 
					ResultSet rs = pst.executeQuery();
					enrolled_table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
		
		public void search_enrolled_cid() {
			try {
				
				//SQL Initialization 
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
				
				if (search_course_ID.getText().equals("")) {
					String query = "SELECT * FROM enrolled";
					PreparedStatement pst = con.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					enrolled_table.setModel(DbUtils.resultSetToTableModel(rs));
				} else 
				{
					String query = "SELECT * FROM enrolled WHERE cid = ?";
					PreparedStatement pst = con.prepareStatement(query);
					
					pst.setString(1, search_course_ID.getText()); 
					ResultSet rs = pst.executeQuery();
					enrolled_table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				
			} catch (Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}

		//Search THROUGH Faculty!
				public void search_faculty_name() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_faculty_name.getText().equals("")) {
							String query = "SELECT * FROM faculty";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							faculty_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM faculty WHERE fname = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_faculty_name.getText()); 
							ResultSet rs = pst.executeQuery();
							faculty_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
				
				public void search_department_ID() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_department_ID.getText().equals("")) {
							String query = "SELECT * FROM faculty";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							faculty_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM faculty WHERE deptid = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_department_ID.getText()); 
							ResultSet rs = pst.executeQuery();
							faculty_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
	
		
				
		//Search THROUGH Staff!
				public void search_staff_name() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_staff_name.getText().equals("")) {
							String query = "SELECT * FROM staff";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							staff_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM staff WHERE sname = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_staff_name.getText()); 
							ResultSet rs = pst.executeQuery();
							staff_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}	
				
				
		//Search THROUGH STUDENTS!
				public void search_student_name() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_student_name.getText().equals("")) {
							String query = "SELECT * FROM students";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM students WHERE sname = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_student_name.getText()); 
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
				
				public void search_student_major() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_student_major.getText().equals("")) {
							String query = "SELECT * FROM students";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM students WHERE major = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_student_major.getText()); 
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
				
				public void search_student_year() {
					try {
						
						//SQL Initialization 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
						
						if (search_student_year.getText().equals("")) {
							String query = "SELECT * FROM students";
							PreparedStatement pst = con.prepareStatement(query);
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						} else 
						{
							String query = "SELECT * FROM students WHERE s_level = ?";
							PreparedStatement pst = con.prepareStatement(query);
							
							pst.setString(1, search_student_year.getText()); 
							ResultSet rs = pst.executeQuery();
							student_table.setModel(DbUtils.resultSetToTableModel(rs));
						}
						
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(null, e);
					}
				}
		
		
		
		
		
//////WELCOME TO THE MAIN FUNCTION!
		
	public staff_search_home() {
		setResizable(false);
		
		getContentPane().setForeground(new Color(0, 0, 0));
		setBackground(new Color(192, 192, 192));
		getContentPane().setBackground(new Color(192, 192, 192));
		getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		setBounds(100, 100, 890, 597);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		new JFrame();
		getContentPane().setForeground(new Color(0, 0, 0));
		setBackground(new Color(192, 192, 192));
		getContentPane().setBackground(new Color(192, 192, 192));
		getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		setBounds(100, 100, 890, 597);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JPanel header = new JPanel();
		header.setBounds(0, 0, 876, 67);
		getContentPane().add(header);
		
		JLabel lblNewLabel = new JLabel("Staff Search");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 50));
		header.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setBackground(new Color(128, 0, 0));
		
		JPanel Database_Selection = new JPanel();
		Database_Selection.setBounds(10, 77, 139, 473);
		getContentPane().add(Database_Selection);
		Database_Selection.setLayout(null);
		
		
		
		
		JLabel lblNewLabel_5 = new JLabel("Search Records:");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 21, 119, 42);
		Database_Selection.add(lblNewLabel_5);
		
		
		

		
		
		JButton btnLogOut = new JButton("Staff Home");
		btnLogOut.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					staff_home stframe;
					try {
						stframe = new staff_home();
						stframe.setVisible(true);			
						dispose();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	
				}
			});
			
		btnLogOut.setBounds(10, 394, 119, 69);
		Database_Selection.add(btnLogOut);
		
		
		layeredSearchPane = new JLayeredPane();
		layeredSearchPane.setBounds(159, 77, 707, 473);
		getContentPane().add(layeredSearchPane);
		layeredSearchPane.setLayout(new CardLayout(0, 0));
		
		JPanel course_search = new JPanel();
		layeredSearchPane.add(course_search, "name_103642348268400");
		course_search.setLayout(null);

		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 135, 687, 328);
		course_search.add(scrollPane);
		
		
		txt_course_name = new JTextField();
		txt_course_name.setBounds(168, 16, 168, 19);
		course_search.add(txt_course_name);
		txt_course_name.setColumns(10);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				search_course_name();
			}
		});
		btnNewButton.setBounds(346, 15, 85, 21);
		course_search.add(btnNewButton);
		
			//Create Course Table 
	
					courses_table = new JTable();
					courses_table.setShowVerticalLines(false);
					scrollPane.setViewportView(courses_table);
					
					courses_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
					courses_table.setFillsViewportHeight(true);
					courses_table.setCellSelectionEnabled(true);
					courses_table.setColumnSelectionAllowed(true);
					courses_table.setEnabled(false);
					
					create_course_table(); //Initial Call
				
				JLabel lblNewLabel_1 = new JLabel("Search by course name:");
				lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1.setBounds(10, 10, 168, 27);
				course_search.add(lblNewLabel_1);
				
				JLabel lblNewLabel_1_1 = new JLabel("Search by course ID:");
				lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1.setBounds(10, 40, 168, 27);
				course_search.add(lblNewLabel_1_1);
				
				txt_course_id = new JTextField();
				txt_course_id.setColumns(10);
				txt_course_id.setBounds(168, 46, 168, 19);
				course_search.add(txt_course_id);
				
				JButton btnNewButton_1 = new JButton("Search");
				btnNewButton_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_course_id();
					}
				});
				btnNewButton_1.setBounds(346, 45, 85, 21);
				course_search.add(btnNewButton_1);
				
				JLabel lblNewLabel_1_1_1 = new JLabel("Search by time:");
				lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_1.setBounds(10, 69, 168, 27);
				course_search.add(lblNewLabel_1_1_1);
				
				txt_course_time = new JTextField();
				txt_course_time.setColumns(10);
				txt_course_time.setBounds(168, 75, 168, 19);
				course_search.add(txt_course_time);
				
				JButton btnNewButton_1_1 = new JButton("Search");
				btnNewButton_1_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_course_time();
					}
				});
				btnNewButton_1_1.setBounds(346, 74, 85, 21);
				course_search.add(btnNewButton_1_1);
				
				JLabel lblNewLabel_1_1_1_1 = new JLabel("Search by Faculty:");
				lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_1_1.setBounds(10, 98, 168, 27);
				course_search.add(lblNewLabel_1_1_1_1);
				
				txt_course_faculty = new JTextField();
				txt_course_faculty.setColumns(10);
				txt_course_faculty.setBounds(168, 104, 168, 19);
				course_search.add(txt_course_faculty);
				
				JButton btnNewButton_1_1_1 = new JButton("Search");
				btnNewButton_1_1_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_course_faculty();
					}
				});
				btnNewButton_1_1_1.setBounds(346, 103, 85, 21);
				course_search.add(btnNewButton_1_1_1);
				
				JPanel department_search = new JPanel();
				department_search.setLayout(null);
				layeredSearchPane.add(department_search, "name_103642379788400");
				
				search_department_id = new JTextField();
				search_department_id.setColumns(10);
				search_department_id.setBounds(209, 17, 168, 19);
				department_search.add(search_department_id);
				
				JButton btnNewButton_2 = new JButton("Search");
				btnNewButton_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_department_id();
					}
				});
				btnNewButton_2.setBounds(387, 16, 85, 21);
				department_search.add(btnNewButton_2);
				
				JLabel lblNewLabel_1_2 = new JLabel("Search by Department ID:");
				lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_2.setBounds(10, 10, 168, 27);
				department_search.add(lblNewLabel_1_2);
				
				JLabel lblNewLabel_1_1_2 = new JLabel("Search by Department Name:");
				lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_2.setBounds(10, 40, 189, 27);
				department_search.add(lblNewLabel_1_1_2);
				
				search_department_name = new JTextField();
				search_department_name.setColumns(10);
				search_department_name.setBounds(209, 47, 168, 19);
				department_search.add(search_department_name);
				
				JButton btnNewButton_1_2 = new JButton("Search");
				btnNewButton_1_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_department_name();
					}
				});
				btnNewButton_1_2.setBounds(387, 46, 85, 21);
				department_search.add(btnNewButton_1_2);
				
				JScrollPane scrollPane_1 = new JScrollPane();
				scrollPane_1.setBounds(10, 77, 687, 386);
				department_search.add(scrollPane_1);
				
				
			//Create Department Table 

				department_table = new JTable();
				scrollPane_1.setViewportView(department_table);
				
				department_table.setShowVerticalLines(false);
				department_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				department_table.setFillsViewportHeight(true);
				department_table.setCellSelectionEnabled(true);
				department_table.setColumnSelectionAllowed(true);
				department_table.setEnabled(false);
				

				create_department_table(); 
				
				JPanel enrolled_search = new JPanel();
				enrolled_search.setLayout(null);
				layeredSearchPane.add(enrolled_search, "name_104758119864100");
				
				search_student_ID = new JTextField();
				search_student_ID.setColumns(10);
				search_student_ID.setBounds(168, 16, 168, 19);
				enrolled_search.add(search_student_ID);
				
				JButton btnNewButton_3 = new JButton("Search");
				btnNewButton_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_enrolled_sid();
					}
				});
				btnNewButton_3.setBounds(346, 15, 85, 21);
				enrolled_search.add(btnNewButton_3);
				
				JLabel lblNewLabel_1_3 = new JLabel("Search by Student ID:");
				lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_3.setBounds(10, 10, 168, 27);
				enrolled_search.add(lblNewLabel_1_3);
				
				JLabel lblNewLabel_1_1_3 = new JLabel("Search by Course ID:");
				lblNewLabel_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_3.setBounds(10, 40, 168, 27);
				enrolled_search.add(lblNewLabel_1_1_3);
				
				search_course_ID = new JTextField();
				search_course_ID.setColumns(10);
				search_course_ID.setBounds(168, 46, 168, 19);
				enrolled_search.add(search_course_ID);
				
				JButton btnNewButton_1_3 = new JButton("Search");
				btnNewButton_1_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_enrolled_cid();
					}
				});
				btnNewButton_1_3.setBounds(346, 45, 85, 21);
				enrolled_search.add(btnNewButton_1_3);
				
				JScrollPane scrollPane_2 = new JScrollPane();
				scrollPane_2.setBounds(10, 77, 687, 386);
				enrolled_search.add(scrollPane_2);
				
				
				
		//Create Enrolled Table 

				enrolled_table = new JTable();
				scrollPane_2.setViewportView(enrolled_table);
				
				enrolled_table.setShowVerticalLines(false);
				enrolled_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				enrolled_table.setFillsViewportHeight(true);
				enrolled_table.setCellSelectionEnabled(true);
				enrolled_table.setColumnSelectionAllowed(true);
				enrolled_table.setEnabled(false);		
				create_enrolled_table();
			
				
				
				
				JPanel faculty_search = new JPanel();
				faculty_search.setLayout(null);
				layeredSearchPane.add(faculty_search, "name_106026089988700");
				
				search_faculty_name = new JTextField();
				search_faculty_name.setColumns(10);
				search_faculty_name.setBounds(199, 17, 168, 19);
				faculty_search.add(search_faculty_name);
				
				JButton btnNewButton_3_1 = new JButton("Search");
				btnNewButton_3_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_faculty_name();
					}
				});
				btnNewButton_3_1.setBounds(377, 16, 85, 21);
				faculty_search.add(btnNewButton_3_1);
				
				JLabel lblNewLabel_1_3_1 = new JLabel("Search by Faculty Name:");
				lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_3_1.setBounds(10, 10, 168, 27);
				faculty_search.add(lblNewLabel_1_3_1);
				
				JLabel lblNewLabel_1_1_3_1 = new JLabel("Search by Department ID:");
				lblNewLabel_1_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_3_1.setBounds(10, 40, 168, 27);
				faculty_search.add(lblNewLabel_1_1_3_1);
				
				search_department_ID = new JTextField();
				search_department_ID.setColumns(10);
				search_department_ID.setBounds(199, 47, 168, 19);
				faculty_search.add(search_department_ID);
				
				JButton btnNewButton_1_3_1 = new JButton("Search");
				btnNewButton_1_3_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_department_ID();
					}
				});
				btnNewButton_1_3_1.setBounds(377, 46, 85, 21);
				faculty_search.add(btnNewButton_1_3_1);
				
				JScrollPane scrollPane_3 = new JScrollPane();
				scrollPane_3.setBounds(10, 77, 687, 386);
				faculty_search.add(scrollPane_3);
				
		
		//Create Faculty Table 

				faculty_table = new JTable();
				scrollPane_3.setViewportView(faculty_table);
				
				faculty_table.setShowVerticalLines(false);
				faculty_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				faculty_table.setFillsViewportHeight(true);
				faculty_table.setCellSelectionEnabled(true);
				faculty_table.setColumnSelectionAllowed(true);
				faculty_table.setEnabled(false);		
				create_faculty_table();
				
				
				JPanel staff_search = new JPanel();
				staff_search.setLayout(null);
				layeredSearchPane.add(staff_search, "name_107788798027100");
				
				search_staff_name = new JTextField();
				search_staff_name.setColumns(10);
				search_staff_name.setBounds(199, 17, 168, 19);
				staff_search.add(search_staff_name);
				
				JButton btnNewButton_3_1_1 = new JButton("Search");
				btnNewButton_3_1_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_staff_name();
					}
				});
				btnNewButton_3_1_1.setBounds(377, 16, 85, 21);
				staff_search.add(btnNewButton_3_1_1);
				
				JLabel lblNewLabel_1_3_1_1 = new JLabel("Search by Staff Name:");
				lblNewLabel_1_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_3_1_1.setBounds(10, 10, 168, 27);
				staff_search.add(lblNewLabel_1_3_1_1);
				
				JScrollPane scrollPane_4 = new JScrollPane();
				scrollPane_4.setBounds(10, 46, 687, 417);
				staff_search.add(scrollPane_4);
				
				
				
				
		//Create Staff Table 

				staff_table = new JTable();
				scrollPane_4.setViewportView(staff_table);
				
				staff_table.setShowVerticalLines(false);
				staff_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				staff_table.setFillsViewportHeight(true);
				staff_table.setCellSelectionEnabled(true);
				staff_table.setColumnSelectionAllowed(true);
				staff_table.setEnabled(false);
				create_staff_table();
				
				JPanel student_search = new JPanel();
				student_search.setLayout(null);
				layeredSearchPane.add(student_search, "name_108986771449000");
				
				JLabel lblNewLabel_1_4 = new JLabel("Search by Student name:");
				lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_4.setBounds(10, 10, 168, 27);
				student_search.add(lblNewLabel_1_4);
				
				JLabel lblNewLabel_1_1_4 = new JLabel("Search by Major:");
				lblNewLabel_1_1_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_4.setBounds(10, 40, 168, 27);
				student_search.add(lblNewLabel_1_1_4);
				
				JLabel lblNewLabel_1_1_1_2 = new JLabel("Search by Year:");
				lblNewLabel_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
				lblNewLabel_1_1_1_2.setBounds(10, 69, 168, 27);
				student_search.add(lblNewLabel_1_1_1_2);
				
				search_student_year = new JTextField();
				search_student_year.setColumns(10);
				search_student_year.setBounds(181, 76, 168, 19);
				student_search.add(search_student_year);
				
				JButton btnNewButton_1_1_2 = new JButton("Search");
				btnNewButton_1_1_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_student_year();
					}
				});
				btnNewButton_1_1_2.setBounds(359, 75, 85, 21);
				student_search.add(btnNewButton_1_1_2);
				
				JButton btnNewButton_1_4 = new JButton("Search");
				btnNewButton_1_4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_student_major();
					}
				});
				btnNewButton_1_4.setBounds(359, 46, 85, 21);
				student_search.add(btnNewButton_1_4);
				
				search_student_major = new JTextField();
				search_student_major.setColumns(10);
				search_student_major.setBounds(181, 47, 168, 19);
				student_search.add(search_student_major);
				
				search_student_name = new JTextField();
				search_student_name.setColumns(10);
				search_student_name.setBounds(181, 17, 168, 19);
				student_search.add(search_student_name);
				
				JButton btnNewButton_4 = new JButton("Search");
				btnNewButton_4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						search_student_name();
					}
				});
				btnNewButton_4.setBounds(359, 16, 85, 21);
				student_search.add(btnNewButton_4);
				
				JScrollPane scrollPane_5 = new JScrollPane();
				scrollPane_5.setBounds(10, 106, 687, 357);
				student_search.add(scrollPane_5);
				
		
	//Student Staff Table 

				student_table = new JTable();
				scrollPane_5.setViewportView(student_table);
				
				student_table.setShowVerticalLines(false);
				student_table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				student_table.setFillsViewportHeight(true);
				student_table.setCellSelectionEnabled(true);
				student_table.setColumnSelectionAllowed(true);
				student_table.setEnabled(false);
				create_students_table();
				
				JButton btnCoursses = new JButton("Courses");
				btnCoursses.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(course_search);
					}
				});
				btnCoursses.setBounds(10, 73, 119, 21);
				Database_Selection.add(btnCoursses);
				
				
				JButton btnDepartment = new JButton("Department");
				btnDepartment.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(department_search);
					}
				});
				btnDepartment.setBounds(10, 120, 119, 21);
				Database_Selection.add(btnDepartment);

		
				JButton btnEnrolled = new JButton("Enrolled");
				btnEnrolled.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(enrolled_search);
					}
				});
				btnEnrolled.setBounds(10, 165, 119, 21);
				Database_Selection.add(btnEnrolled);
				
				
				JButton btnFaculty = new JButton("Faculty");
				btnFaculty.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(faculty_search);
					}
				});
				btnFaculty.setBounds(10, 208, 119, 21);
				Database_Selection.add(btnFaculty);
				
				JButton btnStaff = new JButton("Staff");
				btnStaff.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(staff_search);
					}
				});
				btnStaff.setBounds(10, 255, 119, 21);
				Database_Selection.add(btnStaff);
				
				JButton btnStudents = new JButton("Students");
				btnStudents.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						switchPanels(student_search);
					}
				});
				btnStudents.setBounds(10, 301, 119, 21);
				Database_Selection.add(btnStudents);
	}
}