import java.sql.*;

//Imports for the GUI 
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JPasswordField;

public class DatabaseApplication {

	private static JFrame login_frame;
	private static JTextField txtName;
	private String post = "Student";
	private static JPasswordField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DatabaseApplication window = new DatabaseApplication();
					//window.login_frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					DatabaseApplication.login_frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the application.
	 */
	
	public DatabaseApplication() throws Exception{
		initialize();
	}
	
	
	
	//Logging You In!
	
	static void logIn(String name, int ID, String post) throws Exception{
		
		//SQL Initialization 
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/university_data","root","*id4_As32b");
		
		//Select the entire table from SQL.
		Statement st=con.createStatement();
		
		
		
		switch (post) {
		
			//Student Login
			case "Student":
				ResultSet rs = st.executeQuery("SELECT * FROM students");
				
				while (rs.next()) {
					//rs.next() continues down to the next column. 
					
					//Chop Up Data
					int sid=rs.getInt("sid");
					String sname=rs.getString("sname");	
					
					if (name.equals(sname) && sid == ID) 
					{	
						student_home sframe = new student_home(sid);
						sframe.setVisible(true);			
						login_frame.dispose();
						st.close();
						con.close();						
						return;
					} 
					
				}
				break;
			//Faculty Login
			case "Faculty":
				
				ResultSet rf = st.executeQuery("SELECT * FROM faculty");
				
				
				while (rf.next()) {
					//rf.next() continues down to the next column. 
					
					//Chop Up Data
					int fid=rf.getInt("fid");
					String fname=rf.getString("fname");	
					
					if (name.equals(fname) && fid == ID) 
					{	
						faculty_home fframe = new faculty_home();
						fframe.setVisible(true);			
						login_frame.dispose();
						st.close();
						con.close();						
						return;
					} 
					
				}
				break;
			//Staff Login
			case "Staff":
				
				ResultSet rst = st.executeQuery("SELECT * FROM staff");
				
				while (rst.next()) {
					//rs.next() continues down to the next column. 
					
					//Chop Up Data
					int sid=rst.getInt("sid");
					String sname=rst.getString("sname");	
					
					if (name.equals(sname) && sid == ID) 
					{	
						staff_home stframe = new staff_home();
						stframe.setVisible(true);			
						login_frame.dispose();
						st.close();
						con.close();						
						return;
					} 
					
				}
				break;
		}
		//Reset Login Info
		JOptionPane.showMessageDialog(null, "Incorrect Login information (Error: 1010) Please try again.");
		txtName.setText("");
		textField_1.setText("");
	
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		login_frame = new JFrame();
		login_frame.setResizable(false);
		login_frame.getContentPane().setForeground(new Color(0, 0, 0));
		login_frame.setBackground(new Color(192, 192, 192));
		login_frame.getContentPane().setBackground(new Color(192, 192, 192));
		login_frame.getContentPane().setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		login_frame.setBounds(100, 100, 890, 597);
		login_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		login_frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 876, 67);
		login_frame.getContentPane().add(panel);
		
		JLabel lblNewLabel = new JLabel("SIUC System Database");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 50));
		panel.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(128, 0, 0));
		lblNewLabel.setBackground(new Color(128, 0, 0));
		
		
		//Name Text Field
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(358, 285, 219, 27);
		login_frame.getContentPane().add(txtName);

		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(313, 285, 35, 22);
		login_frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ID:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setBounds(313, 322, 35, 22);
		login_frame.getContentPane().add(lblNewLabel_1_1);
		
		
		
		
		
		
		//Select Type of User
		JComboBox comboBox = new JComboBox();
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(358, 253, 219, 22);
		login_frame.getContentPane().add(comboBox);
		comboBox.addItem("Student");
		comboBox.addItem("Faculty");
		comboBox.addItem("Staff");
		
		//Code For Selecting Post
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					post = comboBox.getSelectedItem().toString();
					
				}
			}
		});
		
		
		
		
		
		
		JLabel lblNewLabel_1_2 = new JLabel("Post:");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setBounds(278, 253, 70, 22);
		login_frame.getContentPane().add(lblNewLabel_1_2);
		
		
		
		
		
		//Enter Data for Login Page!
		
				JButton btnNewButton_1_2 = new JButton("Enter");
				btnNewButton_1_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						
						if (txtName.getText() instanceof String && textField_1.getText() instanceof String)
						{
							String name = txtName.getText();
							
							//Convert to Int
							String ID = textField_1.getText();
							int id;
							
							try {
								id = Integer.parseInt(ID);
							} catch (final NumberFormatException e1) {
								
								//Reset Login Info
								JOptionPane.showMessageDialog(null, "Incorrect Login information (Error: 1001) Please try again.");
								txtName.setText("");
								textField_1.setText("");
								return;
							}
							
							try {
								logIn(name, id, post);
							} catch (Exception e1) {
								
							}
						} else {
							//Reset Login Info
							JOptionPane.showMessageDialog(null, "Incorrect Login information (Error: 1000) Please try again.");
							txtName.setText("");
							textField_1.setText("");
						}
						
						
						
			
						
					}
				});
				
				textField_1 = new JPasswordField();
				textField_1.setBounds(358, 324, 219, 27);
				login_frame.getContentPane().add(textField_1);
				
				btnNewButton_1_2.setForeground(Color.BLACK);
				btnNewButton_1_2.setFont(new Font("Trebuchet MS", Font.BOLD, 15));
				btnNewButton_1_2.setBackground(new Color(220, 220, 220));
				btnNewButton_1_2.setBounds(496, 365, 81, 27);
				login_frame.getContentPane().add(btnNewButton_1_2);
				
				JPanel panel_1 = new JPanel();
				panel_1.setBounds(288, 167, 328, 294);
				login_frame.getContentPane().add(panel_1);
				panel_1.setLayout(null);
				
				JLabel lblNewLabel_2 = new JLabel("Login");
				lblNewLabel_2.setBounds(113, 5, 94, 38);
				lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
				lblNewLabel_2.setForeground(new Color(128, 0, 0));
				lblNewLabel_2.setFont(new Font("Verdana", Font.BOLD, 30));
				lblNewLabel_2.setBackground(new Color(128, 0, 0));
				
				panel_1.add(lblNewLabel_2);

	}
}
